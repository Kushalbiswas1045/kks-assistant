package com.kks.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle

// Invisible activity: launched by the system "assist" gesture (power/home long-press when KKS
// is the default assistant), headset button, or the Quick Settings tile. Starts listening.
class AssistActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(this)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            AssistantService.start(this, "LISTEN")
        } else {
            startActivity(Intent(this, MainActivity::class.java))
        }
        finish()
    }
}
