package com.kks.assistant

import android.animation.ValueAnimator
import android.app.AlertDialog
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.Icon
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.TextView
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import kotlin.math.abs

class AssistantService : Service(), TextToSpeech.OnInitListener {

    companion object {
        @Volatile
        var inst: AssistantService? = null

        fun start(c: Context, action: String? = null) {
            val i = Intent(c, AssistantService::class.java)
            if (action != null) i.action = action
            c.startForegroundService(i)
        }
    }

    private val main = Handler(Looper.getMainLooper())
    private val exec = Executors.newSingleThreadExecutor()
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var rec: SpeechRecognizer? = null
    private lateinit var tools: Tools
    private var state = "idle"
    private var cmdMode = false
    private var voiceTurn = false
    private var listenAfter = false
    private var speakToken = 0
    private var fgStarted = false
    private var bubble: TextView? = null
    private var pulse: ValueAnimator? = null

    override fun onBind(intent: Intent?): IBinder? = null

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            when (i?.action) {
                Intent.ACTION_SCREEN_OFF -> {
                    if (Prefs.i("wake_mode", 0) == 1 && state == "wake") {
                        stopMic()
                        changeState("idle")
                    }
                }
                Intent.ACTION_SCREEN_ON, Intent.ACTION_USER_PRESENT -> {
                    if (state == "idle" && wakeActive()) startRecognizer(false)
                }
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        Prefs.init(this)
        inst = this
        tts = TextToSpeech(this, this)
        tools = Tools(this) { msg -> confirmDialog(msg) }
        val ch = NotificationChannel("kks", "KKS Assistant", NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        val f = IntentFilter()
        f.addAction(Intent.ACTION_SCREEN_OFF)
        f.addAction(Intent.ACTION_SCREEN_ON)
        f.addAction(Intent.ACTION_USER_PRESENT)
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(screenReceiver, f, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(screenReceiver, f)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") {
            stopSelf()
            return START_NOT_STICKY
        }
        if (!fgStarted) {
            try {
                goForeground()
                fgStarted = true
            } catch (e: Exception) {
                Bus.msg("KKS", "Service shuru hoy ni: " + e.message)
                stopSelf()
                return START_NOT_STICKY
            }
        }
        when (intent?.action) {
            "LISTEN" -> main.post { listenNow() }
            "SUBMIT" -> {
                val t = Bus.pendingText
                val m = Bus.attachMime
                val b = Bus.attachB64
                Bus.attachMime = null
                Bus.attachB64 = null
                main.post { submit(t, false, m, b) }
            }
            else -> main.post { reload() }
        }
        return START_STICKY
    }

    private fun goForeground() {
        val stopPi = PendingIntent.getService(
            this, 0, Intent(this, AssistantService::class.java).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE
        )
        val listenPi = PendingIntent.getService(
            this, 2, Intent(this, AssistantService::class.java).setAction("LISTEN"), PendingIntent.FLAG_IMMUTABLE
        )
        val openPi = PendingIntent.getActivity(
            this, 1, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, "kks")
            .setContentTitle("KKS Assistant ready")
            .setContentText("🎙 chapo ba floating KKS bubble-e tap koro")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(openPi)
            .setOngoing(true)
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, android.R.drawable.ic_btn_speak_now), "🎙 Listen", listenPi
                ).build()
            )
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel), "Stop", stopPi
                ).build()
            )
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(1, n)
        }
    }

    // ---------- TTS ----------
    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            ttsReady = true
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) {
                    main.post { if (utteranceId == "u$speakToken" && state == "speaking") afterSpeak() }
                }

                override fun onError(utteranceId: String?) {
                    main.post { if (utteranceId == "u$speakToken" && state == "speaking") afterSpeak() }
                }
            })
            applyVoice()
        } else {
            Bus.ttsInfo = "❌ Text-to-speech engine nei"
        }
    }

    private fun applyVoice() {
        val t = tts ?: return
        if (!ttsReady) return
        val lang = Prefs.s("lang", "bn-BD")
        val r = t.setLanguage(Locale.forLanguageTag(lang))
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            Bus.ttsInfo = "❌ $lang voice nei (kotha shunte parbe na). Phone Settings → Text-to-speech-e Google engine-e voice download koro."
            Bus.msg("KKS", Bus.ttsInfo)
        } else {
            Bus.ttsInfo = "✅ Voice thik ache ($lang)"
        }
        t.setSpeechRate(Prefs.f("rate", 1f))
        t.setPitch(Prefs.f("pitch", 1f))
        val vn = Prefs.s("voice_name", "")
        if (vn.isNotEmpty()) {
            val v = t.voices?.firstOrNull { it.name == vn }
            if (v != null) t.voice = v
        }
    }

    private fun ackText(): String {
        val l = Prefs.s("lang", "bn-BD")
        return when {
            l.startsWith("bn") -> "জি, বলুন"
            l.startsWith("hi") -> "जी, बोलिए"
            else -> "Yes, I'm listening"
        }
    }

    private fun say(text: String) {
        Bus.msg("KKS", text)
        speakText(text, false)
    }

    private fun speakText(text: String, thenListen: Boolean) {
        listenAfter = thenListen
        if (!ttsReady || !Prefs.b("speak", true)) {
            afterSpeak()
            return
        }
        val clean = text.replace(Regex("https?://\\S+"), "")
            .replace(Regex("[*#_`>~|]"), "")
            .replace(Regex("\\s+"), " ").trim().take(900)
        if (clean.isEmpty()) {
            afterSpeak()
            return
        }
        changeState("speaking")
        val token = ++speakToken
        val b = Bundle()
        b.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, Prefs.f("volume", 1f))
        val r = tts?.speak(clean, TextToSpeech.QUEUE_FLUSH, b, "u$token")
        if (r != TextToSpeech.SUCCESS) {
            afterSpeak()
            return
        }
        main.postDelayed({ if (speakToken == token && state == "speaking") afterSpeak() }, 6000L + clean.length * 90L)
    }

    private fun afterSpeak() {
        changeState("idle")
        if (listenAfter) {
            listenAfter = false
            main.postDelayed({ startRecognizer(true) }, 300)
            return
        }
        if (voiceTurn && Prefs.b("continuous", false)) {
            startRecognizer(true)
        } else if (wakeActive()) {
            startRecognizer(false)
        }
    }

    // ---------- Wake word ----------
    private fun wakeActive(): Boolean {
        val m = Prefs.i("wake_mode", 0)
        if (m == 2) return true
        if (m == 1) return getSystemService(PowerManager::class.java).isInteractive
        return false
    }

    private fun wakeRegex(): Regex {
        val greet = "(hi|hey|hello|hai|hay|হাই|হ্যালো|হেই|হায়)"
        val strict = "(k\\s*k\\s*s|k\\s*k\\s*x|কে\\s*কে\\s*এস|কেকেএস|কে\\s*কে\\s*এ্যাস|কেকে\\s*এস)"
        val loose = "(k\\s*k\\s*s|k\\s*k\\s*x|কে\\s*কে\\s*এস|কেকেএস|কে\\s*কে|কেকে|kiks|keks|kex|kicks|কিকস|কেক্স|কেস|কেকস)"
        val sep = "[\\s,.]*"
        val p = when (Prefs.i("wake_sens", 2)) {
            1 -> "$greet$sep$strict"
            2 -> "($greet$sep)?$strict"
            else -> "($greet$sep)?$loose"
        }
        return Regex(p, RegexOption.IGNORE_CASE)
    }

    private fun checkWake(list: List<String>?): Boolean {
        if (state != "wake" || list == null) return false
        val re = wakeRegex()
        for (s in list) {
            val m = re.find(s) ?: continue
            val rest = s.substring(m.range.last + 1).trim().trimStart(',', '.', ' ')
            wakeHeard(rest)
            return true
        }
        return false
    }

    private fun wakeHeard(rest: String) {
        rec?.cancel()
        voiceTurn = true
        if (rest.length >= 2) {
            submit(rest, true, null, null)
        } else {
            // Say "Ji, bolun" first, then listen for the actual command
            speakText(ackText(), true)
        }
    }

    // ---------- Recognition ----------
    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(p0: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(p0: Float) {}
        override fun onBufferReceived(p0: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(p0: Int, p1: Bundle?) {}

        override fun onPartialResults(p0: Bundle?) {
            val l = p0?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            val f = l?.firstOrNull()
            if (!f.isNullOrBlank()) Bus.heard(f)
            if (!cmdMode) checkWake(l)
        }

        override fun onResults(r: Bundle?) {
            val list = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            val f = list?.firstOrNull()
            if (!f.isNullOrBlank()) Bus.heard(f)
            if (cmdMode) {
                if (f.isNullOrBlank()) backToIdle() else submit(f, true, null, null)
            } else {
                if (!checkWake(list)) restartWake(200)
            }
        }

        override fun onError(p0: Int) {
            if (p0 == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                Bus.msg("KKS", "Microphone permission dao.")
                changeState("idle")
                return
            }
            if (cmdMode) {
                Bus.heard("(kichu shunte pai ni, error $p0)")
                backToIdle()
            } else if (state == "wake") {
                restartWake(if (p0 == SpeechRecognizer.ERROR_NO_MATCH || p0 == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) 250 else 1500)
            }
        }
    }

    private fun stopMic() {
        try {
            rec?.cancel()
            rec?.destroy()
        } catch (e: Exception) {
        }
        rec = null
    }

    private fun startRecognizer(cmd: Boolean) {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Bus.msg("KKS", "Speech recognition service nei. Google app install/update koro.")
            return
        }
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return
        cmdMode = cmd
        changeState(if (cmd) "listening" else "wake")
        stopMic()
        rec = SpeechRecognizer.createSpeechRecognizer(this)
        rec?.setRecognitionListener(listener)
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, Prefs.s("lang", "bn-BD"))
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        rec?.startListening(i)
    }

    private fun restartWake(delay: Long) {
        main.postDelayed({
            if (state == "wake" && wakeActive()) startRecognizer(false)
        }, delay)
    }

    private fun backToIdle() {
        if (wakeActive()) {
            startRecognizer(false)
        } else {
            stopMic()
            changeState("idle")
        }
    }

    private fun listenNow() {
        tts?.stop()
        speakToken++
        listenAfter = false
        voiceTurn = true
        try {
            ToneGenerator(AudioManager.STREAM_MUSIC, 80).startTone(ToneGenerator.TONE_PROP_BEEP, 120)
        } catch (e: Exception) {
        }
        main.postDelayed({ startRecognizer(true) }, 200)
    }

    // ---------- Brain ----------
    private fun submit(text: String, voice: Boolean, mime: String?, b64: String?) {
        stopMic()
        voiceTurn = voice
        changeState("thinking")
        Bus.msg("You", text)
        exec.execute {
            val ans = try {
                (if (mime == null) LocalCommands.tryHandle(text, tools) else null)
                    ?: Brain.ask(tools, text, mime, b64)
            } catch (e: Exception) {
                "Error: " + e.message
            }
            main.post { say(ans) }
        }
    }

    private fun reload() {
        applyVoice()
        if (Prefs.b("floating", true)) showBubble() else hideBubble()
        if (state == "idle" || state == "wake") {
            if (wakeActive()) {
                startRecognizer(false)
            } else {
                stopMic()
                changeState("idle")
            }
        }
    }

    // ---------- Confirmation ----------
    private fun confirmDialog(msg: String): Boolean {
        if (!Prefs.b("confirm", true)) return true
        if (!Settings.canDrawOverlays(this)) return false
        val latch = CountDownLatch(1)
        var ok = false
        main.post {
            try {
                val c = ContextThemeWrapper(this, android.R.style.Theme_Material_Light_Dialog_Alert)
                val d = AlertDialog.Builder(c)
                    .setTitle("KKS confirm")
                    .setMessage(msg)
                    .setPositiveButton("Yes / হ্যাঁ") { _, _ -> ok = true; latch.countDown() }
                    .setNegativeButton("No / না") { _, _ -> latch.countDown() }
                    .setOnCancelListener { latch.countDown() }
                    .create()
                d.window?.setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY)
                d.show()
                if (ttsReady && Prefs.b("speak", true)) {
                    tts?.speak(msg.take(200), TextToSpeech.QUEUE_ADD, null, "confirm")
                }
            } catch (e: Exception) {
                latch.countDown()
            }
        }
        latch.await(45, TimeUnit.SECONDS)
        return ok
    }

    // ---------- State / floating bubble ----------
    private fun changeState(s: String) {
        state = s
        Bus.publishState(s)
        updateBubble()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun showBubble() {
        if (bubble != null) return
        if (!Settings.canDrawOverlays(this)) return
        val wm = getSystemService(WindowManager::class.java)
        val b = TextView(this)
        b.text = "KKS"
        b.gravity = Gravity.CENTER
        b.setTextColor(Color.WHITE)
        b.textSize = 13f
        b.typeface = Typeface.DEFAULT_BOLD
        val lp = WindowManager.LayoutParams(
            dp(58), dp(58), WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = 0
        lp.y = dp(200)
        var dx = 0f
        var dy = 0f
        var sx = 0
        var sy = 0
        var moved = false
        b.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    dx = e.rawX; dy = e.rawY; sx = lp.x; sy = lp.y; moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val mx = (e.rawX - dx).toInt()
                    val my = (e.rawY - dy).toInt()
                    if (abs(mx) > 12 || abs(my) > 12) moved = true
                    if (moved) {
                        lp.x = sx + mx
                        lp.y = sy + my
                        wm.updateViewLayout(v, lp)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) listenNow()
                    true
                }
                else -> false
            }
        }
        try {
            wm.addView(b, lp)
            bubble = b
            updateBubble()
        } catch (e: Exception) {
            Bus.msg("KKS", "Floating bubble dekhano gelo na: " + e.message)
        }
    }

    private fun hideBubble() {
        val b = bubble ?: return
        try {
            getSystemService(WindowManager::class.java).removeView(b)
        } catch (e: Exception) {
        }
        bubble = null
        pulse?.cancel()
        pulse = null
    }

    private fun updateBubble() {
        val b = bubble ?: return
        val color = when (state) {
            "listening" -> 0xFFD32F2F.toInt()
            "thinking" -> 0xFFF57C00.toInt()
            "speaking" -> 0xFF2E7D32.toInt()
            "wake" -> 0xFF5E35B1.toInt()
            else -> 0xFF616161.toInt()
        }
        val g = GradientDrawable()
        g.shape = GradientDrawable.OVAL
        g.setColor(color)
        b.background = g
        val active = state == "listening" || state == "speaking" || state == "thinking"
        if (active && pulse == null) {
            val a = ValueAnimator.ofFloat(1f, 1.25f)
            a.duration = 600
            a.repeatMode = ValueAnimator.REVERSE
            a.repeatCount = ValueAnimator.INFINITE
            a.addUpdateListener {
                val v = it.animatedValue as Float
                bubble?.scaleX = v
                bubble?.scaleY = v
            }
            a.start()
            pulse = a
        } else if (!active && pulse != null) {
            pulse?.cancel()
            pulse = null
            b.scaleX = 1f
            b.scaleY = 1f
        }
    }

    override fun onDestroy() {
        try {
            unregisterReceiver(screenReceiver)
        } catch (e: Exception) {
        }
        hideBubble()
        stopMic()
        tts?.shutdown()
        exec.shutdownNow()
        inst = null
        Bus.publishState("off")
        super.onDestroy()
    }
}
