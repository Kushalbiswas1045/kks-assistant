package com.kks.assistant

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Brain {
    // Text-only memory of the conversation (context)
    private val memory = JSONArray()

    private var loaded = false

    private fun load() {
        if (loaded) return
        loaded = true
        try {
            val a = JSONArray(Prefs.s("convo", "[]"))
            for (i in 0 until a.length()) memory.put(a.getJSONObject(i))
        } catch (e: Exception) {
        }
    }

    fun clearMemory() {
        while (memory.length() > 0) memory.remove(0)
        Prefs.put("convo", "[]")
    }

    fun ask(tools: Tools, userText: String, attachMime: String? = null, attachB64: String? = null): String {
        val key = Prefs.s("api_key").trim()
        if (key.isEmpty()) return "Age Settings-e giye Claude API key dao."
        try {
            load()
            val msgs = JSONArray(memory.toString())
            val content = JSONArray()
            if (attachMime != null && attachB64 != null) {
                val type = if (attachMime == "application/pdf") "document" else "image"
                content.put(
                    JSONObject().put("type", type).put(
                        "source",
                        JSONObject().put("type", "base64").put("media_type", attachMime).put("data", attachB64)
                    )
                )
            }
            content.put(JSONObject().put("type", "text").put("text", userText))
            msgs.put(JSONObject().put("role", "user").put("content", content))

            var finalText = ""
            for (step in 0 until 14) {
                val resp = call(key, msgs)
                val blocks = resp.getJSONArray("content")
                msgs.put(JSONObject().put("role", "assistant").put("content", blocks))
                val stop = resp.optString("stop_reason", "")
                val texts = StringBuilder()
                val results = JSONArray()
                for (i in 0 until blocks.length()) {
                    val b = blocks.getJSONObject(i)
                    when (b.optString("type")) {
                        "text" -> texts.append(b.optString("text"))
                        "tool_use" -> {
                            var isErr = false
                            val out: Any = try {
                                tools.run(b.getString("name"), b.optJSONObject("input") ?: JSONObject())
                            } catch (e: Exception) {
                                isErr = true
                                "ERROR: " + (e.message ?: e.javaClass.simpleName)
                            }
                            val r = JSONObject().put("type", "tool_result")
                                .put("tool_use_id", b.getString("id")).put("content", out)
                            if (isErr) r.put("is_error", true)
                            results.put(r)
                        }
                    }
                }
                if (texts.isNotBlank()) finalText = texts.toString().trim()
                if (results.length() > 0) {
                    msgs.put(JSONObject().put("role", "user").put("content", results))
                    continue
                }
                if (stop == "pause_turn") continue
                break
            }
            if (finalText.isEmpty()) finalText = "Kaj sesh."
            remember(if (attachMime != null) "[attachment] $userText" else userText, finalText)
            return finalText
        } catch (e: java.net.UnknownHostException) {
            return "Internet connection nei."
        } catch (e: Exception) {
            return "Error: " + (e.message ?: e.javaClass.simpleName)
        }
    }

    fun ping(): String {
        val key = Prefs.s("api_key").trim()
        if (key.isEmpty()) return "❌ API key nei"
        return try {
            val msgs = JSONArray().put(JSONObject().put("role", "user").put("content", "Reply with the single word OK"))
            call(key, msgs)
            "✅ AI kaj korche (model: " + Prefs.s("model", "claude-sonnet-5-5") + ")"
        } catch (e: java.net.UnknownHostException) {
            "❌ Internet nei"
        } catch (e: Exception) {
            "❌ " + (e.message ?: "error")
        }
    }

    private fun remember(u: String, a: String) {
        memory.put(JSONObject().put("role", "user").put("content", u))
        memory.put(JSONObject().put("role", "assistant").put("content", a))
        while (memory.length() > 24) {
            memory.remove(0)
            memory.remove(0)
        }
        Prefs.put("convo", memory.toString())
    }

    @Volatile
    private var webBroken = false

    private fun post(key: String, model: String, msgs: JSONArray): Pair<Int, String> {
        val body = JSONObject()
            .put("model", model)
            .put("max_tokens", 1500)
            .put("system", systemPrompt())
            .put("messages", msgs)
            .put("tools", toolDefs())
        val conn = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.connectTimeout = 20000
        conn.readTimeout = 120000
        conn.setRequestProperty("content-type", "application/json")
        conn.setRequestProperty("x-api-key", key)
        conn.setRequestProperty("anthropic-version", "2023-06-01")
        conn.doOutput = true
        conn.outputStream.use { it.write(body.toString().toByteArray()) }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
        return Pair(code, text)
    }

    private fun call(key: String, msgs: JSONArray): JSONObject {
        val first = Prefs.s("model", "claude-sonnet-5-5").ifBlank { "claude-sonnet-5-5" }
        val models = listOf(first, "claude-sonnet-4-5", "claude-haiku-4-5-20251001").distinct()
        var lastErr = ""
        for (m in models) {
            var attempt = 0
            while (attempt < 2) {
                attempt++
                val res = post(key, m, msgs)
                val code = res.first
                val text = res.second
                if (code in 200..299) {
                    if (m != first) Prefs.put("model", m)
                    return JSONObject(text)
                }
                lastErr = "API $code: " + text.take(250)
                if (code == 401) throw Exception("API key thik na (401). Settings-e abar key dao.")
                if (code == 400 && text.contains("web_search", true) && Prefs.b("web_search", true)) {
                    Prefs.put("web_search", false)
                    continue
                }
                if (code == 404 || (code == 400 && text.contains("model", true))) break
                throw Exception(lastErr)
            }
        }
        throw Exception(lastErr)
    }

    private fun systemPrompt(): String {
        val now = SimpleDateFormat("EEEE, dd MMMM yyyy, hh:mm a", Locale.US).format(Date())
        val lang = Prefs.s("lang", "bn-BD")
        val pers = Prefs.s("personality", "")
        val mem = Prefs.memories()
        val memBlock = if (mem.isEmpty()) "" else
            "Things the user asked you to remember (use them to answer questions about the user):\n" +
                mem.joinToString("\n") { "- $it" } + "\n"
        return memBlock + "You are KKS, a voice personal assistant living on the user's Android phone. " +
            "Current date/time: $now. Preferred language: $lang. " +
            "Reply in the language the user spoke (Bangla, English, Hindi, or Banglish/Hinglish in Roman script). " +
            "Your replies are spoken aloud, so keep them short and natural, with no markdown, no emoji, no lists. " +
            "Use the provided tools to actually perform phone actions instead of only describing them. " +
            "You can chain several tools for multi-step requests. For app automation: open the app, use read_screen " +
            "to see the UI, then screen_tap / screen_type / screen_scroll, and read_screen again to verify. " +
            "Use analyze_screen when you need to actually see the screen visually. " +
            "Sensitive tools (call, SMS, WhatsApp, delete, power) already ask the user for confirmation inside the app, " +
            "so do not ask again in text. If a tool returns an error or PERMISSION_MISSING, tell the user briefly and clearly " +
            "what failed and what to do. When the task is done, say so in one short sentence. " +
            "Never claim you did something unless a tool result confirms it. " +
            "When the user tells you personal info or asks you to remember something, call save_memory with one clear short sentence. " +
            "When asked about something you may have saved, answer from the remembered list above; if it is not there, say you do not know. " + pers
    }

    private fun t(name: String, desc: String, vararg p: String): JSONObject {
        val props = JSONObject()
        val req = JSONArray()
        for (s in p) {
            val parts = s.split(":", limit = 3)
            val opt = parts[0].endsWith("?")
            val n = parts[0].removeSuffix("?")
            props.put(n, JSONObject().put("type", parts[1]).put("description", parts[2]))
            if (!opt) req.put(n)
        }
        return JSONObject().put("name", name).put("description", desc)
            .put("input_schema", JSONObject().put("type", "object").put("properties", props).put("required", req))
    }

    private fun toolDefs(web: Boolean): JSONArray {
        val a = JSONArray()
        // Apps
        a.put(t("open_app", "Open an installed app by name.", "name:string:App name, e.g. WhatsApp, YouTube, Camera"))
        a.put(t("close_app", "Close/force-stop an app (uses Accessibility).", "name:string:App name"))
        a.put(t("app_settings", "Open the system settings page of an app.", "name:string:App name"))
        a.put(t("list_apps", "List/search installed user apps and count them.", "query?:string:Optional name filter"))
        a.put(t("uninstall_app", "Open the uninstall screen for an app.", "name:string:App name"))
        // Communication
        a.put(t("call", "Phone call a contact name or number (asks user confirmation).", "target:string:Contact name or phone number"))
        a.put(t("send_sms", "Send an SMS (asks user confirmation). Use to also reply to an SMS.", "to:string:Contact name or number", "message:string:Text"))
        a.put(t("read_sms", "Read latest inbox SMS messages.", "count?:integer:How many, default 5"))
        a.put(t("send_whatsapp", "Send a WhatsApp message (asks confirmation).", "to:string:Contact name or number", "message:string:Text"))
        a.put(t("read_notifications", "Read current phone notifications (returns keys)."))
        a.put(t("notification_action", "Act on a notification by key.", "key:string:Notification key", "action:string:dismiss or reply", "text?:string:Reply text when action=reply"))
        a.put(t("email", "Compose an email in the mail app.", "to?:string:Recipient email", "subject?:string:Subject", "body?:string:Body", "auto_send?:boolean:Try to press Send automatically (asks confirmation)"))
        // Media
        a.put(t("media_control", "Control playing media.", "action:string:play, pause, next, previous, stop"))
        a.put(t("volume", "Change media volume.", "action:string:up, down, mute, set", "level?:integer:Percent 0-100 for set"))
        a.put(t("youtube", "Search YouTube for a video or song.", "query:string:Search text"))
        // Camera / media
        a.put(t("camera", "Camera control.", "mode:string:open, photo, video_start, video_stop"))
        a.put(t("gallery", "Open the gallery or search photos.", "action:string:open or search", "query?:string:File name part", "days?:integer:Only photos from last N days"))
        a.put(t("screenshot", "Take a screenshot of the current screen and save it."))
        a.put(t("flashlight", "Turn flashlight on/off.", "on:boolean:true to turn on"))
        // Internet
        a.put(t("web_open", "Open a website URL in the browser.", "url:string:URL or domain"))
        a.put(t("browser_search", "Open a Google search in the browser.", "query:string:Search text"))
        a.put(t("maps", "Maps actions.", "action:string:open, search, navigate, nearby", "query:string:Place, destination or category"))
        a.put(t("get_location", "Get the user's current location."))
        // Time
        a.put(t("set_alarm", "Set an alarm.", "hour:integer:0-23", "minute:integer:0-59", "label?:string:Label"))
        a.put(t("show_alarms", "Open the alarm list."))
        a.put(t("delete_alarm", "Dismiss/delete an alarm at a given time.", "hour:integer:0-23", "minute:integer:0-59"))
        a.put(t("set_timer", "Start a countdown timer.", "seconds:integer:Duration in seconds", "label?:string:Label"))
        a.put(t("stopwatch", "Open the stopwatch and optionally start it.", "start?:boolean:Start it"))
        a.put(t("set_reminder", "Set a reminder today at a time (alarm with message).", "hour:integer:0-23", "minute:integer:0-59", "message:string:What to remind"))
        a.put(t("calendar_add", "Create a calendar event.", "title:string:Title", "date:string:YYYY-MM-DD", "time:string:HH:MM 24h", "duration_min?:integer:Minutes, default 60", "location?:string:Place", "description?:string:Notes"))
        a.put(t("calendar_read", "Read upcoming calendar events.", "days?:integer:Days ahead, default 7"))
        a.put(t("datetime", "Get the current date and time."))
        a.put(t("calculate", "Evaluate a math expression with + - * / ^ % and parentheses.", "expression:string:Expression"))
        // System
        a.put(t("system_settings", "Open a system settings page.", "page:string:wifi, bluetooth, mobile, display, sound, battery, apps, airplane, dnd, storage, location, accessibility, date, language, nfc, main"))
        a.put(t("toggle_setting", "Toggle a quick setting tile via Accessibility (best effort).", "name:string:wifi, bluetooth, airplane, mobile data, hotspot, flashlight, auto-rotate, battery saver, location"))
        a.put(t("brightness", "Set screen brightness.", "level:integer:Percent 0-100"))
        a.put(t("dnd", "Turn Do Not Disturb on/off.", "on:boolean:true to enable"))
        a.put(t("lock_phone", "Lock the phone screen."))
        a.put(t("power", "Open power menu and shutdown/restart (asks confirmation).", "action:string:shutdown or restart"))
        a.put(t("battery", "Battery percentage and charging status."))
        a.put(t("storage", "Storage usage info."))
        a.put(t("device_info", "Phone model and Android version."))
        // Files
        a.put(t("file_search", "Search files by name on shared storage.", "query:string:Name part", "dir?:string:Folder to search in"))
        a.put(t("file_create", "Create a text file.", "path:string:Path relative to storage root or absolute", "content:string:File content"))
        a.put(t("file_rename", "Rename a file (asks confirmation).", "path:string:Path", "new_name:string:New file name"))
        a.put(t("file_delete", "Delete a file (asks confirmation).", "path:string:Path"))
        a.put(t("file_open", "Open a file, or return text of small text files.", "path:string:Path"))
        a.put(t("clipboard", "Clipboard operations.", "action:string:copy, paste, read", "text?:string:Text for copy"))
        // Screen control
        a.put(t("read_screen", "Read the visible text/buttons of the current screen with coordinates."))
        a.put(t("analyze_screen", "Take a screenshot and look at it visually to answer a question.", "question?:string:What to look for"))
        a.put(t("screen_tap", "Tap a UI element by visible text/description, or by x,y.", "text?:string:Visible label", "x?:integer:X coordinate", "y?:integer:Y coordinate"))
        a.put(t("screen_scroll", "Scroll the screen.", "direction:string:up, down, left, right"))
        a.put(t("screen_type", "Type text into the focused or first input field.", "text:string:Text", "submit?:boolean:Press enter/search after typing"))
        a.put(t("nav_action", "System navigation.", "action:string:back, home, recents, notifications, quick_settings"))
        a.put(t("wait", "Wait for the screen to load.", "seconds:integer:1-10"))
        a.put(t("save_memory", "Save a fact about the user to long-term memory.", "text:string:One clear short sentence"))
        a.put(t("list_memories", "List everything saved in memory."))
        a.put(t("delete_memory", "Delete saved memories containing a text.", "query:string:Text to match"))

        if (web && Prefs.b("web_search", true)) {
            a.put(JSONObject().put("type", "web_search_20250305").put("name", "web_search").put("max_uses", 5))
        }
        return a
    }
}
