package com.kks.assistant

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.util.Base64
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.io.ByteArrayOutputStream
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

class KksAccessibilityService : AccessibilityService() {
    companion object {
        @Volatile
        var inst: KksAccessibilityService? = null
    }

    override fun onServiceConnected() {
        inst = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        inst = null
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    fun global(a: Int): Boolean = performGlobalAction(a)

    fun readScreen(): String {
        val root = rootInActiveWindow ?: return "Screen read kora gelo na"
        val sb = StringBuilder("app: ").append(root.packageName).append("\n")
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null || sb.length > 7000) return
            val t = n.text?.toString() ?: ""
            val c = n.contentDescription?.toString() ?: ""
            if (t.isNotEmpty() || c.isNotEmpty() || n.isEditable) {
                val r = Rect()
                n.getBoundsInScreen(r)
                if (n.isEditable) sb.append("[input] ")
                else if (n.isClickable) sb.append("[btn] ")
                sb.append(t)
                if (c.isNotEmpty() && c != t) sb.append(" (").append(c).append(")")
                sb.append(" @").append(r.centerX()).append(",").append(r.centerY()).append("\n")
            }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        return sb.toString()
    }

    fun clickAny(vararg labels: String): Boolean {
        for (l in labels) if (clickText(l)) return true
        return false
    }

    fun clickText(label: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val nodes = root.findAccessibilityNodeInfosByText(label) ?: return false
        for (n in nodes) {
            var x: AccessibilityNodeInfo? = n
            while (x != null && !x.isClickable) x = x.parent
            if (x != null && x.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
        }
        for (n in nodes) {
            val r = Rect()
            n.getBoundsInScreen(r)
            if (r.width() > 0 && r.height() > 0) {
                return tap(r.centerX().toFloat(), r.centerY().toFloat())
            }
        }
        return false
    }

    fun tap(x: Float, y: Float): Boolean {
        val p = Path()
        p.moveTo(x, y)
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, 60)).build()
        return dispatchGesture(g, null, null)
    }

    fun swipe(x1: Float, y1: Float, x2: Float, y2: Float): Boolean {
        val p = Path()
        p.moveTo(x1, y1)
        p.lineTo(x2, y2)
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, 350)).build()
        return dispatchGesture(g, null, null)
    }

    fun scroll(dir: String): Boolean {
        val dm = resources.displayMetrics
        val w = dm.widthPixels.toFloat()
        val h = dm.heightPixels.toFloat()
        return when (dir.lowercase()) {
            "up" -> swipe(w / 2, h * 0.3f, w / 2, h * 0.7f)
            "left" -> swipe(w * 0.2f, h / 2, w * 0.8f, h / 2)
            "right" -> swipe(w * 0.8f, h / 2, w * 0.2f, h / 2)
            else -> swipe(w / 2, h * 0.7f, w / 2, h * 0.3f)
        }
    }

    private fun findEditable(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (n == null) return null
        if (n.isEditable) return n
        for (i in 0 until n.childCount) {
            val r = findEditable(n.getChild(i))
            if (r != null) return r
        }
        return null
    }

    fun typeText(text: String, submit: Boolean): Boolean {
        val root = rootInActiveWindow ?: return false
        var n: AccessibilityNodeInfo? = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        if (n == null || !n.isEditable) n = findEditable(root)
        if (n == null) return false
        val b = Bundle()
        b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        val ok = n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
        if (ok && submit && Build.VERSION.SDK_INT >= 30) {
            Thread.sleep(300)
            n.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
        }
        return ok
    }

    fun paste(): Boolean {
        val root = rootInActiveWindow ?: return false
        var n: AccessibilityNodeInfo? = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        if (n == null) n = findEditable(root)
        if (n == null) return false
        return n.performAction(AccessibilityNodeInfo.ACTION_PASTE)
    }

    fun screenshotB64(): String? {
        if (Build.VERSION.SDK_INT < 30) return null
        var out: String? = null
        val latch = CountDownLatch(1)
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : AccessibilityService.TakeScreenshotCallback {
            override fun onSuccess(r: AccessibilityService.ScreenshotResult) {
                try {
                    val hb = r.hardwareBuffer
                    val bmp = Bitmap.wrapHardwareBuffer(hb, r.colorSpace)
                    if (bmp != null) {
                        val soft = bmp.copy(Bitmap.Config.ARGB_8888, false)
                        if (soft != null) {
                            val maxSide = 1280f
                            val sc = maxSide / Math.max(soft.width, soft.height)
                            val scaled = if (sc < 1f)
                                Bitmap.createScaledBitmap(soft, (soft.width * sc).toInt(), (soft.height * sc).toInt(), true)
                            else soft
                            val bos = ByteArrayOutputStream()
                            scaled.compress(Bitmap.CompressFormat.JPEG, 70, bos)
                            out = Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP)
                        }
                    }
                    hb.close()
                } catch (e: Exception) {
                } finally {
                    latch.countDown()
                }
            }

            override fun onFailure(errorCode: Int) {
                latch.countDown()
            }
        })
        latch.await(6, TimeUnit.SECONDS)
        return out
    }
}
