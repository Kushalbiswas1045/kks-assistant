package com.kks.assistant

import android.app.RemoteInput
import android.content.Intent
import android.os.Bundle
import android.service.notification.NotificationListenerService

class KksNotificationListener : NotificationListenerService() {
    companion object {
        @Volatile
        var inst: KksNotificationListener? = null
    }

    override fun onListenerConnected() {
        inst = this
    }

    override fun onListenerDisconnected() {
        inst = null
    }

    fun list(): String {
        val arr = activeNotifications ?: return "Kono notification nei"
        val sb = StringBuilder()
        var n = 0
        for (s in arr) {
            if (s.packageName == packageName) continue
            if (n >= 15) break
            val ex = s.notification.extras
            val title = ex.getCharSequence("android.title")?.toString() ?: ""
            val text = ex.getCharSequence("android.text")?.toString() ?: ""
            if (title.isEmpty() && text.isEmpty()) continue
            val app = try {
                packageManager.getApplicationLabel(packageManager.getApplicationInfo(s.packageName, 0)).toString()
            } catch (e: Exception) {
                s.packageName
            }
            var canReply = false
            val acts = s.notification.actions
            if (acts != null) {
                for (a in acts) {
                    val ri = a.remoteInputs
                    if (ri != null && ri.isNotEmpty()) canReply = true
                }
            }
            sb.append("[").append(app).append("] ").append(title).append(": ").append(text.take(200))
                .append(if (canReply) " (replyable)" else "")
                .append(" key=").append(s.key).append("\n")
            n++
        }
        return if (sb.isEmpty()) "Kono notification nei" else sb.toString()
    }

    fun dismiss(key: String): Boolean {
        return try {
            cancelNotification(key)
            true
        } catch (e: Exception) {
            false
        }
    }

    fun reply(key: String, text: String): Boolean {
        val sbn = activeNotifications?.firstOrNull { it.key == key } ?: return false
        val actions = sbn.notification.actions ?: return false
        for (a in actions) {
            val ri = a.remoteInputs
            if (ri == null || ri.isEmpty()) continue
            val intent = Intent()
            val b = Bundle()
            for (r in ri) b.putCharSequence(r.resultKey, text)
            RemoteInput.addResultsToIntent(ri, intent, b)
            a.actionIntent.send(this, 0, intent)
            return true
        }
        return false
    }
}
