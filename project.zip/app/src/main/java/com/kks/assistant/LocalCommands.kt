package com.kks.assistant

import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// Fast offline command layer (like Google Assistant / Bixby basics).
// Returns a reply text if it handled the command, or null to let the AI handle it.
object LocalCommands {

    private val aliases = linkedMapOf(
        "ইউটিউব" to "youtube", "you tube" to "youtube",
        "হোয়াটসঅ্যাপ" to "whatsapp", "হোয়াটস অ্যাপ" to "whatsapp", "হোয়াটসএপ" to "whatsapp", "whats app" to "whatsapp",
        "ফেসবুক" to "facebook", "face book" to "facebook", "fb" to "facebook",
        "মেসেঞ্জার" to "messenger", "ইনস্টাগ্রাম" to "instagram", "insta" to "instagram",
        "টেলিগ্রাম" to "telegram", "ক্যামেরা" to "camera", "গ্যালারি" to "gallery", "গ্যালারী" to "gallery",
        "ক্রোম" to "chrome", "গুগল" to "google", "জিমেইল" to "gmail", "ম্যাপস" to "maps", "ম্যাপ" to "maps",
        "সেটিংস" to "settings", "সেটিং" to "settings", "ক্যালকুলেটর" to "calculator", "ঘড়ি" to "clock",
        "ক্যালেন্ডার" to "calendar", "টিকটক" to "tiktok", "স্ন্যাপচ্যাট" to "snapchat",
        "প্লে স্টোর" to "play store", "ফাইল" to "files", "স্পটিফাই" to "spotify", "ইমো" to "imo",
        "বিকাশ" to "bkash", "নগদ" to "nagad", "মেসেজ" to "messages", "ফোন" to "phone"
    )

    fun alias(n: String): String {
        val t = n.lowercase().trim()
        for ((k, v) in aliases) {
            if (t.contains(k)) return t.replace(k, v).trim()
        }
        return t
    }

    private fun r(b: String, e: String): String =
        if (Prefs.s("lang", "bn-BD").startsWith("bn")) b else e

    private fun has(t: String, vararg w: String): Boolean = w.any { t.contains(it) }

    private fun word(t: String, w: String): Boolean =
        Regex("(^|\\s)" + Regex.escape(w) + "(\\s|$)").containsMatchIn(t)

    private fun norm(s: String): String {
        val bn = "০১২৩৪৫৬৭৮৯"
        val sb = StringBuilder()
        for (c in s) {
            val i = bn.indexOf(c)
            sb.append(if (i >= 0) ('0' + i) else c)
        }
        return sb.toString().lowercase().replace(Regex("[।?!,]"), " ").replace(Regex("\\s+"), " ").trim().trimEnd('.')
    }

    fun tryHandle(raw: String, tools: Tools): String? {
        val t = norm(raw)
        if (t.isEmpty()) return null

        // ---- memory ----
        val mm = Regex(
            "^(?:remember(?: that)?|save this|note that|mone rakho|mone rakh|মনে রাখো|মনে রাখ|মনে রেখো)\\s*[:,]?\\s*(.+)$",
            RegexOption.IGNORE_CASE
        ).find(raw.trim())
        if (mm != null) {
            val d = SimpleDateFormat("dd MMM yyyy", Locale.US).format(Date())
            Prefs.addMemory(mm.groupValues[1].trim() + " (" + d + ")")
            return r("মনে রাখলাম।", "Okay, I'll remember that.")
        }

        // ---- flashlight ----
        if (has(t, "flashlight", "flash light", "torch", "টর্চ", "ফ্ল্যাশ")) {
            val off = word(t, "off") || has(t, "bondho", "বন্ধ", "nibhao", "নিভাও", "নিভিয়ে", "turn off")
            tools.run("flashlight", JSONObject().put("on", !off))
            return if (off) r("টর্চ বন্ধ করলাম।", "Flashlight off.") else r("টর্চ জ্বালালাম।", "Flashlight on.")
        }

        // ---- volume ----
        if (has(t, "volume", "ভলিউম", "আওয়াজ")) {
            val lvl = Regex("(\\d{1,3})\\s*(?:%|percent|শতাংশ)?").find(t)
            val act = when {
                has(t, "mute", "silent", "মিউট", "সাইলেন্ট") -> "mute"
                has(t, "increase", "louder", "barao", "বাড়া", "বেশি", "বাড়ান") || word(t, "up") -> "up"
                has(t, "decrease", "lower", "komao", "কমা", "কম", "কমান") || word(t, "down") -> "down"
                lvl != null -> "set"
                else -> ""
            }
            if (act.isNotEmpty()) {
                val o = JSONObject().put("action", act)
                if (act == "set") o.put("level", lvl!!.groupValues[1].toInt())
                tools.run("volume", o)
                return r("ভলিউম ঠিক করলাম।", "Volume changed.")
            }
        }

        // ---- time / date / battery ----
        if (has(t, "what time", "current time", "time koto", "somoy koto", "সময় কত", "কয়টা বাজে", "কটা বাজে", "টাইম কত", "koyta baje", "kota baje")) {
            val tm = SimpleDateFormat("hh:mm a", Locale.US).format(Date())
            return r("এখন সময় $tm", "It's $tm")
        }
        if (word(t, "date") || has(t, "tarikh", "তারিখ", "what day", "আজ কি বার", "আজ কী বার")) {
            val d = SimpleDateFormat("EEEE, dd MMMM yyyy", Locale.US).format(Date())
            return r("আজ $d", "Today is $d")
        }
        if (has(t, "battery", "ব্যাটারি", "বেটারি", "charge koto", "চার্জ কত")) {
            return tools.run("battery", JSONObject()).toString()
        }

        // ---- alarm ----
        if (has(t, "alarm", "অ্যালার্ম", "এলার্ম", "আলার্ম") && !has(t, "delete", "cancel", "মুছে", "বাতিল", "বন্ধ") && !word(t, "off")) {
            val m = Regex("(\\d{1,2})(?:\\s*[:.]\\s*(\\d{2}))?").find(t)
            if (m != null) {
                var h = m.groupValues[1].toInt()
                var min = if (m.groupValues[2].isNotEmpty()) m.groupValues[2].toInt() else 0
                if (has(t, "সাড়ে", "sare", "half")) min = 30
                val pm = Regex("(^|[\\d\\s])pm(\\s|$)").containsMatchIn(t) ||
                    has(t, "বিকাল", "বিকেল", "রাত", "সন্ধ্যা", "দুপুর", "evening", "night", "afternoon", "raat", "bikel", "sondha")
                val am = Regex("(^|[\\d\\s])am(\\s|$)").containsMatchIn(t) || has(t, "সকাল", "morning", "shokal")
                if (pm && h < 12) h += 12
                if (am && h == 12) h = 0
                if (h in 0..23 && min in 0..59) {
                    tools.run("set_alarm", JSONObject().put("hour", h).put("minute", min))
                    val s = "%02d:%02d".format(h, min)
                    return r("অ্যালার্ম সেট করলাম $s", "Alarm set for $s")
                }
            }
        }

        // ---- timer ----
        if (has(t, "timer", "টাইমার")) {
            val m = Regex("(\\d+)\\s*(hours?|hrs?|ঘণ্টা|ঘন্টা|ghonta|minutes?|mins?|মিনিট|minit|seconds?|secs?|সেকেন্ড)").find(t)
            if (m != null) {
                val n = m.groupValues[1].toInt()
                val u = m.groupValues[2]
                val sec = when {
                    u.startsWith("h") || u.contains("ঘ") || u.startsWith("ghonta") -> n * 3600
                    u.startsWith("m") || u.contains("মিনিট") -> n * 60
                    else -> n
                }
                tools.run("set_timer", JSONObject().put("seconds", sec))
                return r("টাইমার শুরু করলাম।", "Timer started.")
            }
        }

        // ---- open app ----
        val openRes = listOf(
            Regex("^(?:please\\s+)?(?:open|launch|start|run)\\s+(?:the\\s+)?(.+?)(?:\\s+app)?$"),
            Regex("^(.+?)\\s*(?:app)?\\s*(?:খোলো|খুলো|খোল|খুল|ওপেন করো|ওপেন কর|ওপেন|চালু করো|চালু কর|চালাও)$"),
            Regex("^(.+?)\\s+(?:kholo|khulo|khol|open koro|open kor|chalu koro|chalu kor|chalao)$"),
            Regex("^(?:খোলো|ওপেন)\\s+(.+)$")
        )
        for (re in openRes) {
            val m = re.find(t) ?: continue
            val name = m.groupValues[1].trim()
            if (name.isEmpty() || name.split(" ").size > 3) continue
            if (has(t, " and ", " then ", "তারপর", " আর ")) continue
            val res = tools.run("open_app", JSONObject().put("name", name)).toString()
            return if (res.startsWith("Opened")) r("$name খুলছি।", "Opening $name.") else null
        }

        // ---- call ----
        val callRes = listOf(
            Regex("^(?:call|dial|phone|ring)\\s+(.+)$"),
            Regex("^(.+?)\\s*(?:কে)?\\s*(?:কল|ফোন)\\s*(?:করো|কর|দাও|দে|লাগাও)$"),
            Regex("^(.+?)\\s+(?:ke\\s+)?(?:call|phone|fon)\\s+(?:koro|kor|dao|de)$")
        )
        for (re in callRes) {
            val m = re.find(t) ?: continue
            val name = m.groupValues[1].trim()
            if (name.isEmpty()) continue
            val res = tools.run("call", JSONObject().put("target", name)).toString()
            return if (res.startsWith("Calling")) r("কল করছি।", "Calling.") else res
        }

        // ---- media ----
        if (has(t, "next song", "next track", "skip song", "পরের গান", "porer gan", "next gan")) {
            tools.run("media_control", JSONObject().put("action", "next"))
            return r("পরের গান।", "Next song.")
        }
        if (has(t, "previous song", "previous track", "আগের গান", "ager gan")) {
            tools.run("media_control", JSONObject().put("action", "previous"))
            return r("আগের গান।", "Previous song.")
        }
        if (has(t, "pause", "stop music", "gan thamao", "গান থামাও", "থামাও", "থামান")) {
            tools.run("media_control", JSONObject().put("action", "pause"))
            return r("থামালাম।", "Paused.")
        }
        if (has(t, "resume", "play music", "gan chalao", "গান চালাও", "মিউজিক চালাও")) {
            tools.run("media_control", JSONObject().put("action", "play"))
            return r("চালাচ্ছি।", "Playing.")
        }

        // ---- youtube ----
        if (has(t, "youtube", "ইউটিউব", "you tube")) {
            var q = t
            for (w in listOf("play", "search", "open", "on", "in", "for", "video", "watch", "youtube", "you tube")) {
                q = q.replace(Regex("(^|\\s)" + w + "(\\s|$)"), " ")
            }
            for (w in listOf("ইউটিউবে", "ইউটিউব", "চালাও", "দেখাও", "খোঁজো", "খুঁজো", "সার্চ", "করো", "কর", "ভিডিও")) {
                q = q.replace(w, " ")
            }
            q = q.replace(Regex("\\s+"), " ").trim()
            return if (q.isEmpty()) {
                tools.run("open_app", JSONObject().put("name", "youtube"))
                r("ইউটিউব খুলছি।", "Opening YouTube.")
            } else {
                tools.run("youtube", JSONObject().put("query", q))
                r("ইউটিউবে খুঁজছি: $q", "Searching YouTube for $q.")
            }
        }

        // ---- camera ----
        if (has(t, "take a photo", "take photo", "take a picture", "take picture", "selfie", "ছবি তোলো", "ছবি তুলো", "ছবি তোল", "photo tolo", "chobi tolo", "ফটো তোলো")) {
            tools.run("camera", JSONObject().put("mode", "photo"))
            return r("ছবি তুললাম।", "Photo taken.")
        }
        if (has(t, "record video", "video record", "ভিডিও রেকর্ড", "ভিডিও করো")) {
            tools.run("camera", JSONObject().put("mode", "video_start"))
            return r("ভিডিও রেকর্ড শুরু।", "Recording started.")
        }
        if (has(t, "stop recording", "রেকর্ড বন্ধ", "রেকর্ডিং বন্ধ")) {
            tools.run("camera", JSONObject().put("mode", "video_stop"))
            return r("রেকর্ড বন্ধ।", "Recording stopped.")
        }

        // ---- screen / system ----
        if (has(t, "screenshot", "screen shot", "স্ক্রিনশট")) {
            return tools.run("screenshot", JSONObject()).toString()
        }
        if (has(t, "lock the phone", "lock phone", "lock my phone", "ফোন লক", "phone lock", "screen lock")) {
            return tools.run("lock_phone", JSONObject()).toString()
        }
        if (t == "go home" || t == "home" || t == "home screen" || has(t, "হোমে যাও", "হোম স্ক্রিনে")) {
            tools.run("nav_action", JSONObject().put("action", "home"))
            return r("হোমে এলাম।", "Home.")
        }
        if (t == "go back" || t == "back" || has(t, "পিছনে যাও", "পেছনে যাও")) {
            tools.run("nav_action", JSONObject().put("action", "back"))
            return r("পিছনে গেলাম।", "Back.")
        }
        if (has(t, "do not disturb", "dnd", "ডিস্টার্ব")) {
            val off = word(t, "off") || has(t, "বন্ধ", "bondho", "disable")
            return tools.run("dnd", JSONObject().put("on", !off)).toString()
        }
        val tog = when {
            has(t, "wifi", "wi-fi", "wi fi", "ওয়াই-ফাই", "ওয়াইফাই", "ওয়াই ফাই") -> "wifi"
            has(t, "bluetooth", "ব্লুটুথ") -> "bluetooth"
            has(t, "airplane", "flight mode", "এয়ারপ্লেন", "ফ্লাইট মোড") -> "airplane"
            has(t, "hotspot", "হটস্পট") -> "hotspot"
            has(t, "mobile data", "মোবাইল ডেটা", "মোবাইল data") -> "mobile data"
            else -> ""
        }
        if (tog.isNotEmpty() && (word(t, "on") || word(t, "off") || has(t, "chalu", "বন্ধ", "চালু", "enable", "disable", "turn", "koro", "করো", "settings", "সেটিংস"))) {
            val wantsSettings = has(t, "settings", "সেটিংস")
            if (KksAccessibilityService.inst != null && !wantsSettings) {
                tools.run("toggle_setting", JSONObject().put("name", tog))
                return r("$tog টগল করলাম।", "Toggled $tog.")
            }
            val page = if (tog == "mobile data") "mobile" else tog
            tools.run("system_settings", JSONObject().put("page", page))
            return r("$tog সেটিংস খুলেছি।", "Opened $tog settings.")
        }

        // ---- navigation / search ----
        val navRes = listOf(
            Regex("^(?:navigate|directions?|take me|route)\\s+(?:to\\s+)?(.+)$"),
            Regex("^(.+?)\\s*(?:যাওয়ার রাস্তা|নেভিগেট করো|নেভিগেশন)$")
        )
        for (re in navRes) {
            val m = re.find(t) ?: continue
            tools.run("maps", JSONObject().put("action", "navigate").put("query", m.groupValues[1].trim()))
            return r("নেভিগেশন শুরু।", "Starting navigation.")
        }
        val searchRes = listOf(
            Regex("^(?:search|google)\\s+(?:for\\s+)?(.+)$"),
            Regex("^(.+?)\\s*(?:সার্চ করো|সার্চ কর|খোঁজো|খুঁজো)$"),
            Regex("^(?:সার্চ করো|search koro)\\s+(.+)$")
        )
        for (re in searchRes) {
            val m = re.find(t) ?: continue
            val q = m.groupValues[1].trim()
            if (has(q, "weather", "আবহাওয়া", "news", "খবর", "price", "score")) continue
            tools.run("browser_search", JSONObject().put("query", q))
            return r("সার্চ করছি।", "Searching.")
        }

        // ---- read things ----
        if (has(t, "read notification", "notifications poro", "notification poro", "নোটিফিকেশন পড়")) {
            val x = tools.run("read_notifications", JSONObject()).toString()
            return x.replace(Regex("\\s*key=\\S+"), "").take(700)
        }
        if (has(t, "read my sms", "read sms", "read messages", "sms poro", "মেসেজ পড়", "এসএমএস পড়")) {
            return tools.run("read_sms", JSONObject().put("count", 3)).toString().take(700)
        }
        if (has(t, "read screen", "read the screen", "screen poro", "স্ক্রিন পড়", "স্ক্রিনে কি লেখা", "স্ক্রিনে কী লেখা")) {
            val x = tools.run("read_screen", JSONObject()).toString()
            return x.replace(Regex(" @\\d+,\\d+"), "").replace("[btn] ", "").replace("[input] ", "").take(700)
        }
        if (has(t, "stopwatch", "স্টপওয়াচ")) {
            tools.run("stopwatch", JSONObject().put("start", has(t, "start", "শুরু")))
            return r("স্টপওয়াচ খুলেছি।", "Stopwatch opened.")
        }

        return null
    }
}
