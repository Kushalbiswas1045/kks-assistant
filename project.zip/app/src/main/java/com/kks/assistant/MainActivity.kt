package com.kks.assistant

import android.Manifest
import android.animation.ObjectAnimator
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Base64
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.ByteArrayOutputStream

class MainActivity : Activity() {
    private lateinit var chat: TextView
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private lateinit var status: TextView
    private var pulse: ObjectAnimator? = null

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        Prefs.init(this)
        setTheme(
            if (Prefs.b("dark")) android.R.style.Theme_Material_NoActionBar
            else android.R.style.Theme_Material_Light_NoActionBar
        )
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(12), dp(36), dp(12), dp(8))

        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        val title = TextView(this)
        title.text = "KKS"
        title.textSize = 24f
        status = TextView(this)
        status.text = "● off"
        status.textSize = 14f
        val settingsBtn = Button(this)
        settingsBtn.text = "⚙"
        settingsBtn.setOnClickListener { startActivity(Intent(this, SettingsActivity::class.java)) }
        val histBtn = Button(this)
        histBtn.text = "🕘"
        histBtn.setOnClickListener { showHistory() }
        top.addView(title, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        top.addView(status)
        top.addView(histBtn)
        top.addView(settingsBtn)

        chat = TextView(this)
        chat.textSize = 16f
        chat.setTextIsSelectable(true)
        scroll = ScrollView(this)
        scroll.addView(chat)

        input = EditText(this)
        input.hint = "Command likho..."

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER
        val mic = Button(this)
        mic.text = "🎙"
        mic.setOnClickListener {
            ensureService()
            AssistantService.start(this, "LISTEN")
        }
        val send = Button(this)
        send.text = "Send"
        send.setOnClickListener {
            val t = input.text.toString().trim()
            if (t.isNotEmpty()) {
                input.setText("")
                Bus.pendingText = t
                AssistantService.start(this, "SUBMIT")
            }
        }
        val attach = Button(this)
        attach.text = "📎"
        attach.setOnClickListener {
            val i = Intent(Intent.ACTION_GET_CONTENT)
            i.type = "*/*"
            i.putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("image/*", "application/pdf"))
            startActivityForResult(i, 77)
        }
        val power = Button(this)
        power.text = "⏻"
        power.setOnClickListener {
            if (Bus.state == "off") {
                ensureService()
            } else {
                startService(Intent(this, AssistantService::class.java).setAction("STOP"))
            }
        }
        row.addView(mic)
        row.addView(send)
        row.addView(attach)
        row.addView(power)

        root.addView(top)
        root.addView(scroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(input)
        root.addView(row)
        setContentView(root)

        requestMissingPermissions()
        if (!Prefs.b("welcomed")) {
            Prefs.put("welcomed", true)
            Bus.msg(
                "KKS",
                "Swagatam! Prothome ⚙ Settings-e giye Claude API key dao, tarpor Permissions section-e Accessibility, " +
                    "Overlay, Notification access, All files access on koro. Tarpor \"Hi KKS\" bolo ba 🎙 chapo."
            )
        }
    }

    private fun requestMissingPermissions() {
        val list = ArrayList<String>()
        list.add(Manifest.permission.RECORD_AUDIO)
        list.add(Manifest.permission.CALL_PHONE)
        list.add(Manifest.permission.READ_CONTACTS)
        list.add(Manifest.permission.SEND_SMS)
        list.add(Manifest.permission.READ_SMS)
        list.add(Manifest.permission.READ_CALENDAR)
        list.add(Manifest.permission.WRITE_CALENDAR)
        list.add(Manifest.permission.CAMERA)
        list.add(Manifest.permission.ACCESS_FINE_LOCATION)
        list.add(Manifest.permission.ACCESS_COARSE_LOCATION)
        if (Build.VERSION.SDK_INT >= 33) {
            list.add(Manifest.permission.POST_NOTIFICATIONS)
            list.add(Manifest.permission.READ_MEDIA_IMAGES)
        } else {
            list.add(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
        val missing = list.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) requestPermissions(missing.toTypedArray(), 1) else ensureService()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        ensureService()
    }

    private fun ensureService() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Age Microphone permission dao", Toast.LENGTH_LONG).show()
            return
        }
        if (Bus.state == "off") AssistantService.start(this)
    }

    override fun onResume() {
        super.onResume()
        chat.text = ""
        for (l in Prefs.history().takeLast(30)) chat.append(l + "\n\n")
        scrollDown()
        updateStatus(Bus.state)
        Bus.onMsg = { who, text ->
            chat.append("$who: $text\n\n")
            scrollDown()
        }
        Bus.onState = { s -> updateStatus(s) }
    }

    override fun onPause() {
        super.onPause()
        Bus.onMsg = null
        Bus.onState = null
        pulse?.cancel()
    }

    private fun scrollDown() {
        scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
    }

    private fun updateStatus(s: String) {
        status.text = when (s) {
            "wake" -> "● Hi KKS shunchi"
            "listening" -> "● shunchi..."
            "thinking" -> "● vabchi..."
            "speaking" -> "● bolchi..."
            "idle" -> "● idle"
            else -> "● off"
        }
        pulse?.cancel()
        if (s == "listening" || s == "speaking" || s == "thinking") {
            val a = ObjectAnimator.ofFloat(status, "alpha", 1f, 0.3f)
            a.duration = 500
            a.repeatMode = ObjectAnimator.REVERSE
            a.repeatCount = ObjectAnimator.INFINITE
            a.start()
            pulse = a
        } else {
            status.alpha = 1f
        }
    }

    private fun showHistory() {
        val h = Prefs.history().takeLast(100).joinToString("\n\n")
        AlertDialog.Builder(this)
            .setTitle("Command history")
            .setMessage(if (h.isEmpty()) "Kichu nei" else h)
            .setPositiveButton("OK", null)
            .setNegativeButton("Clear") { _, _ ->
                Prefs.clearHistory()
                Brain.clearMemory()
                chat.text = ""
            }
            .show()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val u = data?.data
        if (requestCode == 77 && resultCode == RESULT_OK && u != null) {
            attachFile(u)
        }
    }

    private fun decode(uri: Uri): Bitmap {
        val o = BitmapFactory.Options()
        o.inJustDecodeBounds = true
        contentResolver.openInputStream(uri)!!.use { BitmapFactory.decodeStream(it, null, o) }
        var s = 1
        while (o.outWidth / s > 2000 || o.outHeight / s > 2000) s *= 2
        val o2 = BitmapFactory.Options()
        o2.inSampleSize = s
        return contentResolver.openInputStream(uri)!!.use { BitmapFactory.decodeStream(it, null, o2) }
            ?: throw Exception("Image porha gelo na")
    }

    private fun attachFile(uri: Uri) {
        val question = input.text.toString().trim().ifEmpty { "Ei file/chhobi-ta analyse kore bujhiye bolo." }
        input.setText("")
        Toast.makeText(this, "File pathacchi...", Toast.LENGTH_SHORT).show()
        Thread {
            try {
                val mime = contentResolver.getType(uri) ?: "image/jpeg"
                val b64: String
                val outMime: String
                if (mime == "application/pdf") {
                    val bytes = contentResolver.openInputStream(uri)!!.use { it.readBytes() }
                    if (bytes.size > 8_000_000) throw Exception("PDF boro (8MB er beshi)")
                    b64 = Base64.encodeToString(bytes, Base64.NO_WRAP)
                    outMime = "application/pdf"
                } else {
                    val bmp = decode(uri)
                    val bos = ByteArrayOutputStream()
                    bmp.compress(Bitmap.CompressFormat.JPEG, 85, bos)
                    b64 = Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP)
                    outMime = "image/jpeg"
                }
                runOnUiThread {
                    Bus.pendingText = question
                    Bus.attachMime = outMime
                    Bus.attachB64 = b64
                    AssistantService.start(this, "SUBMIT")
                }
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(this, "Error: " + e.message, Toast.LENGTH_LONG).show() }
            }
        }.start()
    }
}
