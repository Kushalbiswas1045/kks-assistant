package com.kks.assistant

import android.content.Context
import android.content.SharedPreferences
import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject

object Prefs {
    private var sp: SharedPreferences? = null

    fun init(c: Context) {
        if (sp == null) sp = c.applicationContext.getSharedPreferences("kks", Context.MODE_PRIVATE)
    }

    private fun p(): SharedPreferences = sp ?: throw IllegalStateException("Prefs not init")

    fun s(k: String, d: String = ""): String = p().getString(k, d) ?: d
    fun b(k: String, d: Boolean = false): Boolean = p().getBoolean(k, d)
    fun f(k: String, d: Float): Float = p().getFloat(k, d)
    fun i(k: String, d: Int): Int = p().getInt(k, d)

    fun put(k: String, v: Any) {
        val e = p().edit()
        when (v) {
            is String -> e.putString(k, v)
            is Boolean -> e.putBoolean(k, v)
            is Float -> e.putFloat(k, v)
            is Int -> e.putInt(k, v)
        }
        e.apply()
    }

    fun addHistory(who: String, text: String) {
        if (!b("save_history", true)) return
        val a = try { JSONArray(s("history", "[]")) } catch (e: Exception) { JSONArray() }
        a.put(JSONObject().put("w", who).put("t", text))
        while (a.length() > 150) a.remove(0)
        put("history", a.toString())
    }

    fun history(): List<String> {
        val out = ArrayList<String>()
        try {
            val a = JSONArray(s("history", "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out.add(o.getString("w") + ": " + o.getString("t"))
            }
        } catch (e: Exception) {
        }
        return out
    }

    fun clearHistory() {
        put("history", "[]")
    }
}

object Bus {
    var onMsg: ((String, String) -> Unit)? = null
    var onState: ((String) -> Unit)? = null

    @Volatile
    var state: String = "off"
    var pendingText: String = ""
    var attachMime: String? = null
    var attachB64: String? = null

    private val h = Handler(Looper.getMainLooper())

    fun msg(who: String, text: String) {
        Prefs.addHistory(who, text)
        h.post { onMsg?.invoke(who, text) }
    }

    fun setState(s: String) {
        state = s
        h.post { onState?.invoke(s) }
    }
}
