package com.kks.assistant

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.NotificationManager
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.PowerManager
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import java.util.Locale

class SettingsActivity : Activity() {
    private lateinit var box: LinearLayout
    private var tts: TextToSpeech? = null

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        Prefs.init(this)
        setTheme(
            if (Prefs.b("dark")) android.R.style.Theme_Material_NoActionBar
            else android.R.style.Theme_Material_Light_NoActionBar
        )
        super.onCreate(savedInstanceState)
        val sv = ScrollView(this)
        box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(16), dp(40), dp(16), dp(24))
        sv.addView(box)
        setContentView(sv)
    }

    override fun onResume() {
        super.onResume()
        build()
    }

    override fun onPause() {
        super.onPause()
        if (Bus.state != "off") AssistantService.start(this, "RELOAD")
    }

    override fun onDestroy() {
        tts?.shutdown()
        super.onDestroy()
    }

    // ---------- UI helpers ----------
    private fun header(t: String) {
        val v = TextView(this)
        v.text = t
        v.textSize = 18f
        v.setPadding(0, dp(22), 0, dp(6))
        box.addView(v)
    }

    private fun label(t: String) {
        val v = TextView(this)
        v.text = t
        v.textSize = 14f
        v.setPadding(0, dp(6), 0, 0)
        box.addView(v)
    }

    private fun sw(text: String, key: String, def: Boolean, after: (() -> Unit)? = null) {
        val s = Switch(this)
        s.text = text
        s.isChecked = Prefs.b(key, def)
        s.setOnCheckedChangeListener { _, c ->
            Prefs.put(key, c)
            after?.invoke()
        }
        box.addView(s)
    }

    private fun edit(text: String, key: String, secret: Boolean, multi: Boolean) {
        label(text)
        val e = EditText(this)
        e.setText(Prefs.s(key, ""))
        if (secret) e.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        if (multi) {
            e.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            e.minLines = 2
        }
        e.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                Prefs.put(key, s.toString().trim())
            }
        })
        box.addView(e)
    }

    // value = min + progress * step
    private fun seek(text: String, key: String, min: Float, max: Float, def: Float) {
        val steps = 20
        val cur = Prefs.f(key, def)
        val lab = TextView(this)
        lab.text = text + ": " + "%.2f".format(cur)
        lab.setPadding(0, dp(8), 0, 0)
        val sb = SeekBar(this)
        sb.max = steps
        sb.progress = (((cur - min) / (max - min)) * steps).toInt().coerceIn(0, steps)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                val v = min + (max - min) * p / steps
                Prefs.put(key, v)
                lab.text = text + ": " + "%.2f".format(v)
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        box.addView(lab)
        box.addView(sb)
    }

    private fun btn(text: String, action: () -> Unit) {
        val b = Button(this)
        b.text = text
        b.setOnClickListener { action() }
        box.addView(b)
    }

    private fun permRow(text: String, ok: Boolean, action: () -> Unit) {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        val t = TextView(this)
        t.text = (if (ok) "✅ " else "❌ ") + text
        t.textSize = 15f
        r.addView(t, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        if (!ok) {
            val b = Button(this)
            b.text = "Allow"
            b.setOnClickListener { action() }
            r.addView(b)
        }
        box.addView(r)
    }

    // ---------- Build ----------
    private fun build() {
        box.removeAllViews()
        val title = TextView(this)
        title.text = "KKS Settings"
        title.textSize = 24f
        box.addView(title)

        header("🧠 AI")
        edit("Claude API key", "api_key", true, false)
        if (Prefs.s("model", "").isEmpty()) Prefs.put("model", "claude-sonnet-5-5")
        edit("Model", "model", false, false)
        edit("AI personality (optional, jemon: tumi hasi-khushi bondhu)", "personality", false, true)
        sw("Internet search (web search tool)", "web_search", true)
        edit("Country code (0-diye number-er jonno, jemon 880)", "country_code", false, false)

        header("🎙️ Voice & Language")
        btn("Language: " + Prefs.s("lang", "bn-BD")) { pickLanguage() }
        seek("Voice speed", "rate", 0.5f, 2f, 1f)
        seek("Voice pitch", "pitch", 0.5f, 2f, 1f)
        seek("Voice volume", "volume", 0f, 1f, 1f)
        sw("Voice-e uttor dao", "speak", true)
        btn("KKS voice bachai koro") { pickVoice() }
        btn("Voice test") { testVoice() }
        btn("Phone-er Text-to-speech settings (Bangla voice download)") {
            try {
                startActivity(Intent("com.android.settings.TTS_SETTINGS"))
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_SETTINGS))
            }
        }

        header("👂 Wake word")
        val modes = arrayOf("Off (mic sob somoy on thakbe na)", "Screen on thakle", "Always (mic sob somoy on)")
        btn("\"Hi KKS\" wake word: " + modes[Prefs.i("wake_mode", 0).coerceIn(0, 2)]) {
            AlertDialog.Builder(this).setTitle("Wake word")
                .setItems(modes) { _, i ->
                    Prefs.put("wake_mode", i)
                    build()
                }.show()
        }
        label("Wake word off thakle ba onno assistant (Google/Bixby) chalate: floating KKS bubble, notification-er 🎙 Listen button, Quick Settings tile, ba KKS-ke default assistant kore power/home long-press e dako.")
        btn("Default assistant app bachai koro") {
            try {
                startActivity(Intent(Settings.ACTION_VOICE_INPUT_SETTINGS))
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_SETTINGS))
            }
        }
        seek("Sensitivity (1 strict, 3 sensitive)", "wake_sens_f", 1f, 3f, 2f)
        Prefs.put("wake_sens", Math.round(Prefs.f("wake_sens_f", 2f)))
        sw("Continuous conversation", "continuous", false)
        sw("Floating KKS bubble", "floating", true)

        header("🎨 Interface")
        sw("Dark mode", "dark", false) { recreate() }

        header("🔐 Privacy")
        sw("Sensitive action-er age confirmation", "confirm", true)
        sw("Conversation history save koro", "save_history", true)
        btn("Saved memory (voice-e bola tathyo) dekho") {
            val m = Prefs.memories()
            AlertDialog.Builder(this).setTitle("KKS memory")
                .setMessage(if (m.isEmpty()) "Kichu nei" else m.joinToString("\n• ", "• "))
                .setPositiveButton("OK", null)
                .setNegativeButton("Sob muche felo") { _, _ -> Prefs.put("memories", "[]") }
                .show()
        }
        btn("Conversation history muche felo") {
            Prefs.clearHistory()
            Brain.clearMemory()
        }

        header("🛡️ Permission dashboard")
        val rt = ArrayList<Triple<String, Array<String>, Boolean>>()
        rt.add(Triple("Microphone", arrayOf(Manifest.permission.RECORD_AUDIO), true))
        rt.add(Triple("Phone call", arrayOf(Manifest.permission.CALL_PHONE), true))
        rt.add(Triple("Contacts", arrayOf(Manifest.permission.READ_CONTACTS), true))
        rt.add(Triple("SMS send", arrayOf(Manifest.permission.SEND_SMS), true))
        rt.add(Triple("SMS read", arrayOf(Manifest.permission.READ_SMS), true))
        rt.add(Triple("Calendar", arrayOf(Manifest.permission.READ_CALENDAR, Manifest.permission.WRITE_CALENDAR), true))
        rt.add(Triple("Camera", arrayOf(Manifest.permission.CAMERA), true))
        rt.add(Triple("Location", arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), true))
        if (Build.VERSION.SDK_INT >= 33) {
            rt.add(Triple("Notifications", arrayOf(Manifest.permission.POST_NOTIFICATIONS), true))
            rt.add(Triple("Photos", arrayOf(Manifest.permission.READ_MEDIA_IMAGES), true))
        } else {
            rt.add(Triple("Storage read", arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE), true))
        }
        for (p in rt) {
            val ok = p.second.all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }
            permRow(p.first, ok) { requestPermissions(p.second, 5) }
        }

        label("Special access (settings page-e giye on korte hobe):")
        val pkgUri = Uri.parse("package:$packageName")
        permRow("Overlay (onno app-er upor floating)", Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, pkgUri))
        }
        val enabledAcc = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
        permRow("Accessibility (tap, scroll, type, screen porha)", enabledAcc.contains(packageName)) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        val enabledNl = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: ""
        permRow("Notification access", enabledNl.contains(packageName)) {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        val allFiles = if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager() else true
        permRow("All files access", allFiles) {
            startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, pkgUri))
        }
        permRow("Modify system settings (brightness)", Settings.System.canWrite(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, pkgUri))
        }
        permRow("Do Not Disturb access", getSystemService(NotificationManager::class.java).isNotificationPolicyAccessGranted) {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
        }
        permRow("Battery optimization off (background-e cholar jonno)", getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(packageName)) {
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, pkgUri))
        }
        label("Accessibility on na hole (restricted): App info → ⋮ → Allow restricted settings, tarpor abar Accessibility-te jao.")
        btn("App info kholo") {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkgUri))
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        build()
    }

    // ---------- Dialogs ----------
    private fun pickLanguage() {
        val names = arrayOf("বাংলা (bn-BD)", "English (en-US)", "English India (en-IN)", "हिन्दी (hi-IN)")
        val tags = arrayOf("bn-BD", "en-US", "en-IN", "hi-IN")
        AlertDialog.Builder(this).setTitle("Language")
            .setItems(names) { _, i ->
                Prefs.put("lang", tags[i])
                build()
            }.show()
    }

    private fun pickVoice() {
        tts?.shutdown()
        tts = TextToSpeech(this) { st ->
            if (st == TextToSpeech.SUCCESS) runOnUiThread { showVoices() }
        }
    }

    private fun showVoices() {
        val t = tts ?: return
        val lang = Prefs.s("lang", "bn-BD").substringBefore("-")
        val all = (t.voices ?: emptySet()).filter { it.locale.language == lang }.sortedBy { it.name }
        if (all.isEmpty()) {
            AlertDialog.Builder(this).setMessage("Ei bhasar kono voice nei. Phone Settings → Text-to-speech-e voice download koro.")
                .setPositiveButton("OK", null).show()
            return
        }
        val names = ArrayList<String>()
        names.add("Default")
        for (v in all) names.add(v.name)
        AlertDialog.Builder(this).setTitle("KKS voice")
            .setItems(names.toTypedArray()) { _, i ->
                if (i == 0) Prefs.put("voice_name", "") else Prefs.put("voice_name", all[i - 1].name)
            }.show()
    }

    private fun testVoice() {
        tts?.shutdown()
        tts = TextToSpeech(this) { st ->
            val t = tts
            if (st == TextToSpeech.SUCCESS && t != null) {
                t.language = Locale.forLanguageTag(Prefs.s("lang", "bn-BD"))
                t.setSpeechRate(Prefs.f("rate", 1f))
                t.setPitch(Prefs.f("pitch", 1f))
                val vn = Prefs.s("voice_name", "")
                if (vn.isNotEmpty()) t.voices?.firstOrNull { it.name == vn }?.let { t.voice = it }
                val b = Bundle()
                b.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, Prefs.f("volume", 1f))
                t.speak("Ami KKS, tomar personal assistant.", TextToSpeech.QUEUE_FLUSH, b, "test")
            }
        }
    }
}
