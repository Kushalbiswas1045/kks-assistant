package com.kks.assistant

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.app.NotificationManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.location.Geocoder
import android.location.Location
import android.location.LocationManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.provider.AlarmClock
import android.provider.CalendarContract
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.provider.Telephony
import android.telephony.SmsManager
import android.view.KeyEvent
import android.webkit.MimeTypeMap
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class Tools(private val ctx: Context, private val confirm: (String) -> Boolean) {

    fun run(name: String, a: JSONObject): Any {
        return when (name) {
            "open_app" -> openApp(a.getString("name"))
            "close_app" -> closeApp(a.getString("name"))
            "app_settings" -> appSettings(a.getString("name"))
            "list_apps" -> listApps(a.optString("query", ""))
            "uninstall_app" -> uninstall(a.getString("name"))
            "call" -> call(a.getString("target"))
            "send_sms" -> sendSms(a.getString("to"), a.getString("message"))
            "read_sms" -> readSms(a.optInt("count", 5))
            "send_whatsapp" -> sendWhatsapp(a.getString("to"), a.getString("message"))
            "read_notifications" -> KksNotificationListener.inst?.list()
                ?: "Notification access on nei. Settings → Permissions theke on koro."
            "notification_action" -> notifAction(a.getString("key"), a.getString("action"), a.optString("text", ""))
            "email" -> email(a.optString("to", ""), a.optString("subject", ""), a.optString("body", ""), a.optBoolean("auto_send", false))
            "media_control" -> mediaControl(a.getString("action"))
            "volume" -> volume(a.getString("action"), a.optInt("level", 50))
            "youtube" -> youtube(a.getString("query"))
            "camera" -> camera(a.getString("mode"))
            "gallery" -> gallery(a.optString("action", "open"), a.optString("query", ""), a.optInt("days", 0))
            "screenshot" -> screenshot()
            "flashlight" -> flashlight(a.getBoolean("on"))
            "web_open" -> webOpen(a.getString("url"))
            "browser_search" -> browserSearch(a.getString("query"))
            "maps" -> maps(a.getString("action"), a.getString("query"))
            "get_location" -> locationInfo()
            "set_alarm" -> setAlarm(a.getInt("hour"), a.getInt("minute"), a.optString("label", "KKS"))
            "show_alarms" -> {
                launch(Intent(AlarmClock.ACTION_SHOW_ALARMS))
                "Alarm list khulechi"
            }
            "delete_alarm" -> deleteAlarm(a.getInt("hour"), a.getInt("minute"))
            "set_timer" -> setTimer(a.getInt("seconds"), a.optString("label", "KKS"))
            "stopwatch" -> stopwatch(a.optBoolean("start", false))
            "set_reminder" -> setAlarm(a.getInt("hour"), a.getInt("minute"), "Reminder: " + a.getString("message"))
            "calendar_add" -> calendarAdd(a)
            "calendar_read" -> calendarRead(a.optInt("days", 7))
            "datetime" -> SimpleDateFormat("EEEE, dd MMMM yyyy, hh:mm a", Locale.US).format(Date())
            "calculate" -> calculate(a.getString("expression"))
            "system_settings" -> settingsPage(a.getString("page"))
            "toggle_setting" -> toggleSetting(a.getString("name"))
            "brightness" -> brightness(a.getInt("level"))
            "dnd" -> dnd(a.getBoolean("on"))
            "lock_phone" -> {
                if (acc().global(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN)) "Phone lock hoyeche" else "Lock kora gelo na"
            }
            "power" -> power(a.getString("action"))
            "battery" -> battery()
            "storage" -> storage()
            "device_info" -> "${Build.MANUFACTURER} ${Build.MODEL}, Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})"
            "file_search" -> fileSearch(a.getString("query"), a.optString("dir", ""))
            "file_create" -> fileCreate(a.getString("path"), a.getString("content"))
            "file_rename" -> fileRename(a.getString("path"), a.getString("new_name"))
            "file_delete" -> fileDelete(a.getString("path"))
            "file_open" -> fileOpen(a.getString("path"))
            "clipboard" -> clipboard(a.getString("action"), a.optString("text", ""))
            "read_screen" -> acc().readScreen()
            "analyze_screen" -> analyzeScreen(a.optString("question", "Screen-e ki ache?"))
            "screen_tap" -> screenTap(a.optString("text", ""), a.optInt("x", -1), a.optInt("y", -1))
            "screen_scroll" -> {
                acc().scroll(a.optString("direction", "down"))
                sleep(500)
                "Scrolled"
            }
            "screen_type" -> {
                if (acc().typeText(a.getString("text"), a.optBoolean("submit", false))) "Typed" else "Input field pai ni"
            }
            "nav_action" -> navAction(a.getString("action"))
            "wait" -> {
                sleep(a.optInt("seconds", 1).coerceIn(1, 10) * 1000L)
                "Waited"
            }
            "save_memory" -> {
                Prefs.addMemory(a.getString("text"))
                "Mone rakhlam"
            }
            "list_memories" -> Prefs.memories().joinToString("\n").ifEmpty { "Kichu save kora nei" }
            "delete_memory" -> Prefs.deleteMemory(a.getString("query")).toString() + " memory muche felechi"
            else -> "Unknown tool: $name"
        }
    }

    // ---------- helpers ----------
    private fun sleep(ms: Long) {
        Thread.sleep(ms)
    }

    private fun has(p: String): Boolean = ctx.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    private fun need(p: String, label: String): String? =
        if (has(p)) null else "PERMISSION_MISSING: $label. User-ke Settings → Permissions-e giye allow korte bolo."

    private fun launch(i: Intent) {
        if (!Bus.uiVisible && !Settings.canDrawOverlays(ctx) && KksAccessibilityService.inst == null) {
            throw Exception("PERMISSION_MISSING: Overlay permission off, tai onno app khola jabe na. KKS Settings → Permissions → Overlay on koro.")
        }
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    }

    private fun acc(): KksAccessibilityService = KksAccessibilityService.inst
        ?: throw Exception("Accessibility service on nei. Settings → Permissions → Accessibility on koro.")

    private fun findApp(n: String): ResolveInfo? {
        val r = findApp0(n)
        if (r != null) return r
        val a = LocalCommands.alias(n)
        return if (a != n.lowercase().trim()) findApp0(a) else null
    }

    private fun findApp0(n: String): ResolveInfo? {
        val pm = ctx.packageManager
        val q = n.lowercase().trim()
        val list = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        return list.firstOrNull { it.loadLabel(pm).toString().lowercase() == q }
            ?: list.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(q) }
            ?: list.firstOrNull { it.activityInfo.packageName.lowercase().contains(q) }
    }

    // ---------- apps ----------
    private fun openApp(n: String): String {
        val r = findApp(n) ?: return "App pawa jay ni: $n"
        val i = ctx.packageManager.getLaunchIntentForPackage(r.activityInfo.packageName)
            ?: return "Launch kora gelo na"
        launch(i)
        return "Opened " + r.loadLabel(ctx.packageManager)
    }

    private fun closeApp(n: String): String {
        val r = findApp(n) ?: return "App pawa jay ni: $n"
        val pkg = r.activityInfo.packageName
        val s = acc()
        launch(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg")))
        sleep(1600)
        val ok = s.clickAny("Force stop", "জোর করে বন্ধ", "বন্ধ করুন", "Stop")
        if (!ok) {
            s.global(AccessibilityService.GLOBAL_ACTION_HOME)
            return "Force stop button pai ni"
        }
        sleep(1000)
        s.clickAny("OK", "ঠিক আছে", "Force stop")
        sleep(600)
        s.global(AccessibilityService.GLOBAL_ACTION_HOME)
        return "App bondho kora hoyeche"
    }

    private fun appSettings(n: String): String {
        val r = findApp(n) ?: return "App pawa jay ni: $n"
        launch(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + r.activityInfo.packageName)))
        return "App settings khulechi"
    }

    private fun listApps(q: String): String {
        val pm = ctx.packageManager
        val apps = pm.getInstalledApplications(0)
            .filter { (it.flags and ApplicationInfo.FLAG_SYSTEM) == 0 }
            .map { pm.getApplicationLabel(it).toString() }
            .filter { it.contains(q, true) }
            .sorted()
        return "${apps.size} user apps: " + apps.take(80).joinToString(", ")
    }

    private fun uninstall(n: String): String {
        val r = findApp(n) ?: return "App pawa jay ni: $n"
        launch(Intent(Intent.ACTION_DELETE, Uri.parse("package:" + r.activityInfo.packageName)))
        return "Uninstall screen khulechi, user-ke confirm korte hobe"
    }

    // ---------- contacts / calls / sms ----------
    private fun contactNumber(q: String): Pair<String, String>? {
        if (!has(Manifest.permission.READ_CONTACTS)) return null
        val c = ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            ), null, null, null
        ) ?: return null
        var found: Pair<String, String>? = null
        c.use {
            while (it.moveToNext()) {
                val n = it.getString(0) ?: continue
                val num = it.getString(1) ?: continue
                if (n.equals(q, true)) {
                    found = Pair(n, num)
                    break
                }
                if (found == null && n.contains(q, true)) found = Pair(n, num)
            }
        }
        return found
    }

    private fun target(t: String): Pair<String, String> {
        if (Regex("^\\+?[\\d][\\d\\s-]{4,}$").matches(t.trim())) {
            return Pair(t.trim(), t.replace(Regex("[\\s-]"), ""))
        }
        if (!has(Manifest.permission.READ_CONTACTS)) throw Exception("PERMISSION_MISSING: Contacts")
        return contactNumber(t) ?: throw Exception("Contact pai ni: $t")
    }

    private fun call(t: String): String {
        val (name, num) = target(t)
        if (!confirm("$name ($num) -ke call korbo?")) return "User call cancel korlo"
        if (!has(Manifest.permission.CALL_PHONE)) {
            launch(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$num")))
            return "CALL permission nei, dialer khulechi"
        }
        launch(Intent(Intent.ACTION_CALL, Uri.parse("tel:$num")))
        return "Calling $name"
    }

    @Suppress("DEPRECATION")
    private fun smsManager(): SmsManager =
        if (Build.VERSION.SDK_INT >= 31) ctx.getSystemService(SmsManager::class.java) else SmsManager.getDefault()

    private fun sendSms(to: String, msg: String): String {
        need(Manifest.permission.SEND_SMS, "SMS send")?.let { return it }
        val (name, num) = target(to)
        if (!confirm("$name ($num)-ke SMS pathabo?\n\"$msg\"")) return "User cancel korlo"
        val sm = smsManager()
        sm.sendMultipartTextMessage(num, null, sm.divideMessage(msg), null, null)
        return "SMS pathano hoyeche"
    }

    private fun readSms(n: Int): String {
        need(Manifest.permission.READ_SMS, "SMS read")?.let { return it }
        val c = ctx.contentResolver.query(
            Telephony.Sms.Inbox.CONTENT_URI, arrayOf("address", "body", "date"), null, null, "date DESC"
        ) ?: return "SMS read kora gelo na"
        val sb = StringBuilder()
        var k = 0
        c.use {
            while (it.moveToNext() && k < n) {
                sb.append(it.getString(0)).append(": ").append(it.getString(1)?.take(300)).append("\n")
                k++
            }
        }
        return if (sb.isEmpty()) "Kono SMS nei" else sb.toString()
    }

    private fun waNumber(num: String): String {
        var d = num.filter { it.isDigit() }
        if (d.startsWith("00")) d = d.substring(2)
        else if (d.startsWith("0")) d = Prefs.s("country_code", "880") + d.substring(1)
        return d
    }

    private fun sendWhatsapp(to: String, msg: String): String {
        val (name, num) = target(to)
        if (!confirm("WhatsApp-e $name-ke pathabo?\n\"$msg\"")) return "User cancel korlo"
        val uri = Uri.parse("https://wa.me/" + waNumber(num) + "?text=" + Uri.encode(msg))
        try {
            launch(Intent(Intent.ACTION_VIEW, uri).setPackage("com.whatsapp"))
        } catch (e: Exception) {
            launch(Intent(Intent.ACTION_VIEW, uri))
        }
        val s = acc()
        for (i in 0 until 6) {
            sleep(1200)
            if (s.clickAny("Send", "পাঠান")) return "WhatsApp message pathano hoyeche"
        }
        return "WhatsApp chat khulechi kintu Send button pai ni, user-ke nije Send chapte hobe"
    }

    private fun notifAction(key: String, action: String, text: String): String {
        val l = KksNotificationListener.inst ?: return "Notification access on nei"
        return when (action) {
            "dismiss" -> if (l.dismiss(key)) "Notification soriyechi" else "Hoy ni"
            "reply" -> {
                if (!confirm("Notification-e reply pathabo?\n\"$text\"")) "User cancel korlo"
                else if (l.reply(key, text)) "Reply pathano hoyeche" else "Reply kora gelo na"
            }
            else -> "Unknown action"
        }
    }

    private fun email(to: String, subject: String, body: String, autoSend: Boolean): String {
        val i = Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:"))
        if (to.isNotEmpty()) i.putExtra(Intent.EXTRA_EMAIL, arrayOf(to))
        i.putExtra(Intent.EXTRA_SUBJECT, subject)
        i.putExtra(Intent.EXTRA_TEXT, body)
        if (autoSend && !confirm("Email pathabo? ($to)\n$subject")) return "User cancel korlo"
        launch(i)
        if (autoSend) {
            val s = acc()
            for (k in 0 until 5) {
                sleep(1200)
                if (s.clickAny("Send", "পাঠান")) return "Email pathano hoyeche"
            }
            return "Email compose khulechi, Send button pai ni"
        }
        return "Email compose khulechi, user Send chapbe"
    }

    // ---------- media ----------
    private fun mediaControl(act: String): String {
        val am = ctx.getSystemService(AudioManager::class.java)
        val code = when (act) {
            "play" -> KeyEvent.KEYCODE_MEDIA_PLAY
            "pause" -> KeyEvent.KEYCODE_MEDIA_PAUSE
            "next" -> KeyEvent.KEYCODE_MEDIA_NEXT
            "previous" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
            "stop" -> KeyEvent.KEYCODE_MEDIA_STOP
            else -> KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
        }
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
        return "Media $act"
    }

    private fun volume(act: String, level: Int): String {
        val am = ctx.getSystemService(AudioManager::class.java)
        when (act) {
            "up" -> am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
            "down" -> am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
            "mute" -> am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI)
            else -> {
                val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                am.setStreamVolume(AudioManager.STREAM_MUSIC, max * level.coerceIn(0, 100) / 100, AudioManager.FLAG_SHOW_UI)
            }
        }
        val cur = am.getStreamVolume(AudioManager.STREAM_MUSIC)
        val mx = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        return "Volume $cur/$mx"
    }

    private fun youtube(q: String): String {
        launch(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(q))))
        return "YouTube-e '$q' search khulechi. Video play korte read_screen diye result dekhe tap koro."
    }

    // ---------- camera / gallery ----------
    private fun camera(mode: String): String {
        if (mode == "open") {
            launch(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA))
            return "Camera khulechi"
        }
        if (mode == "photo") {
            launch(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA))
            sleep(2500)
            return if (pressShutter()) "Photo tola hoyeche" else "Camera khulechi, shutter pai ni"
        }
        if (mode == "video_start") {
            launch(Intent(MediaStore.INTENT_ACTION_VIDEO_CAMERA))
            sleep(2500)
            return if (pressShutter()) "Video recording shuru" else "Video camera khulechi, record button pai ni"
        }
        return if (pressShutter()) "Recording bondho" else "Stop button pai ni"
    }

    private fun pressShutter(): Boolean {
        val s = acc()
        if (s.clickAny("Shutter", "Take photo", "Take picture", "Capture", "Record", "Start recording", "Stop recording", "Stop", "শাটার")) return true
        val dm = ctx.resources.displayMetrics
        return s.tap(dm.widthPixels / 2f, dm.heightPixels * 0.88f)
    }

    private fun gallery(act: String, q: String, days: Int): String {
        if (act == "search") {
            if (!has(Manifest.permission.READ_MEDIA_IMAGES) && !has(Manifest.permission.READ_EXTERNAL_STORAGE)) {
                return "PERMISSION_MISSING: Photos. Settings → Permissions-e allow koro."
            }
            val sel = StringBuilder("1=1")
            val args = ArrayList<String>()
            if (q.isNotBlank()) {
                sel.append(" AND ").append(MediaStore.Images.Media.DISPLAY_NAME).append(" LIKE ?")
                args.add("%$q%")
            }
            if (days > 0) {
                sel.append(" AND ").append(MediaStore.Images.Media.DATE_ADDED).append(" >= ?")
                args.add(((System.currentTimeMillis() / 1000) - days * 86400L).toString())
            }
            val c = ctx.contentResolver.query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                arrayOf(MediaStore.Images.Media.DISPLAY_NAME, MediaStore.Images.Media.DATE_ADDED),
                sel.toString(), args.toTypedArray(), MediaStore.Images.Media.DATE_ADDED + " DESC"
            ) ?: return "Search kora gelo na"
            val sb = StringBuilder()
            var count = 0
            c.use {
                while (it.moveToNext()) {
                    if (count < 15) {
                        val d = SimpleDateFormat("dd MMM yyyy", Locale.US).format(Date(it.getLong(1) * 1000))
                        sb.append(it.getString(0)).append(" (").append(d).append(")\n")
                    }
                    count++
                }
            }
            return "$count photo pawa gelo.\n$sb"
        }
        try {
            launch(Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_GALLERY))
        } catch (e: Exception) {
            launch(Intent(Intent.ACTION_VIEW).setType("image/*"))
        }
        return "Gallery khulechi"
    }

    private fun screenshot(): String {
        return if (acc().global(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT)) "Screenshot neya hoyeche" else "Screenshot neya gelo na"
    }

    private fun flashlight(on: Boolean): String {
        val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        var id: String? = null
        for (c in cm.cameraIdList) {
            if (cm.getCameraCharacteristics(c).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true) {
                id = c
                break
            }
        }
        if (id == null) return "Flash nei"
        cm.setTorchMode(id, on)
        return if (on) "Flashlight on" else "Flashlight off"
    }

    // ---------- web / maps / location ----------
    private fun webOpen(u: String): String {
        val url = if (u.startsWith("http")) u else "https://$u"
        launch(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        return "Opened $url"
    }

    private fun browserSearch(q: String): String {
        launch(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q))))
        return "Google search khulechi"
    }

    @Suppress("MissingPermission")
    private fun safeLoc(lm: LocationManager, p: String): Location? = try {
        lm.getLastKnownLocation(p)
    } catch (e: Exception) {
        null
    }

    private fun lastLocation(): Location? {
        if (!has(Manifest.permission.ACCESS_FINE_LOCATION) && !has(Manifest.permission.ACCESS_COARSE_LOCATION)) return null
        val lm = ctx.getSystemService(LocationManager::class.java)
        var best: Location? = null
        for (p in lm.getProviders(true)) {
            val l = safeLoc(lm, p) ?: continue
            val b = best
            if (b == null || l.accuracy < b.accuracy) best = l
        }
        return best
    }

    @Suppress("DEPRECATION")
    private fun locationInfo(): String {
        need(Manifest.permission.ACCESS_FINE_LOCATION, "Location")?.let { return it }
        val l = lastLocation() ?: return "Location pawa jay ni. GPS on kore Maps ekbar kholo."
        var addr = ""
        try {
            val list = Geocoder(ctx, Locale.getDefault()).getFromLocation(l.latitude, l.longitude, 1)
            if (list != null && list.isNotEmpty()) addr = list[0].getAddressLine(0) ?: ""
        } catch (e: Exception) {
        }
        return "lat=${l.latitude}, lng=${l.longitude}. $addr"
    }

    private fun maps(act: String, q: String): String {
        val uri: Uri = when (act) {
            "navigate" -> Uri.parse("google.navigation:q=" + Uri.encode(q))
            "nearby" -> {
                val l = lastLocation()
                if (l != null) Uri.parse("geo:${l.latitude},${l.longitude}?q=" + Uri.encode(q))
                else Uri.parse("geo:0,0?q=" + Uri.encode("$q near me"))
            }
            else -> Uri.parse("geo:0,0?q=" + Uri.encode(q))
        }
        try {
            launch(Intent(Intent.ACTION_VIEW, uri).setPackage("com.google.android.apps.maps"))
        } catch (e: Exception) {
            launch(Intent(Intent.ACTION_VIEW, uri))
        }
        return "Maps: $act $q"
    }

    // ---------- time ----------
    private fun setAlarm(h: Int, m: Int, label: String): String {
        launch(
            Intent(AlarmClock.ACTION_SET_ALARM)
                .putExtra(AlarmClock.EXTRA_HOUR, h)
                .putExtra(AlarmClock.EXTRA_MINUTES, m)
                .putExtra(AlarmClock.EXTRA_MESSAGE, label)
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        )
        return "Alarm set: %02d:%02d".format(h, m)
    }

    private fun deleteAlarm(h: Int, m: Int): String {
        launch(
            Intent(AlarmClock.ACTION_DISMISS_ALARM)
                .putExtra(AlarmClock.EXTRA_ALARM_SEARCH_MODE, AlarmClock.ALARM_SEARCH_MODE_TIME)
                .putExtra(AlarmClock.EXTRA_HOUR, h)
                .putExtra(AlarmClock.EXTRA_MINUTES, m)
        )
        return "Alarm dismiss request pathano hoyeche"
    }

    private fun setTimer(sec: Int, label: String): String {
        launch(
            Intent(AlarmClock.ACTION_SET_TIMER)
                .putExtra(AlarmClock.EXTRA_LENGTH, sec)
                .putExtra(AlarmClock.EXTRA_MESSAGE, label)
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        )
        return "Timer set: $sec sec"
    }

    private fun stopwatch(start: Boolean): String {
        val r = openApp("clock")
        if (r.startsWith("App pawa")) return r
        sleep(1800)
        val s = acc()
        s.clickAny("Stopwatch", "স্টপওয়াচ")
        if (start) {
            sleep(700)
            s.clickAny("Start", "শুরু")
        }
        return "Stopwatch khulechi"
    }

    private fun calendarAdd(a: JSONObject): String {
        val f = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)
        val start = f.parse(a.getString("date") + " " + a.getString("time"))?.time ?: return "Date/time thik na"
        val end = start + a.optInt("duration_min", 60) * 60000L
        launch(
            Intent(Intent.ACTION_INSERT).setData(CalendarContract.Events.CONTENT_URI)
                .putExtra(CalendarContract.Events.TITLE, a.getString("title"))
                .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, start)
                .putExtra(CalendarContract.EXTRA_EVENT_END_TIME, end)
                .putExtra(CalendarContract.Events.EVENT_LOCATION, a.optString("location", ""))
                .putExtra(CalendarContract.Events.DESCRIPTION, a.optString("description", ""))
        )
        val s = KksAccessibilityService.inst
        if (s != null) {
            sleep(2000)
            s.clickAny("Save", "সংরক্ষণ", "Done")
            return "Calendar event save kora hoyeche (ba save screen khulechi)"
        }
        return "Calendar event screen khulechi, user Save chapbe"
    }

    private fun calendarRead(days: Int): String {
        need(Manifest.permission.READ_CALENDAR, "Calendar")?.let { return it }
        val now = System.currentTimeMillis()
        val c = CalendarContract.Instances.query(
            ctx.contentResolver,
            arrayOf(CalendarContract.Instances.TITLE, CalendarContract.Instances.BEGIN, CalendarContract.Instances.EVENT_LOCATION),
            now, now + days * 86400000L
        ) ?: return "Calendar read kora gelo na"
        val sb = StringBuilder()
        val f = SimpleDateFormat("EEE dd MMM, hh:mm a", Locale.US)
        c.use {
            while (it.moveToNext()) {
                sb.append(f.format(Date(it.getLong(1)))).append(" - ").append(it.getString(0))
                val loc = it.getString(2)
                if (!loc.isNullOrEmpty()) sb.append(" @ ").append(loc)
                sb.append("\n")
            }
        }
        return if (sb.isEmpty()) "Kono event nei" else sb.toString()
    }

    private class Calc(val s: String) {
        var p = 0
        fun parse(): Double {
            val v = expr()
            ws()
            if (p < s.length) throw Exception("Expression bujhini")
            return v
        }

        fun ws() {
            while (p < s.length && s[p] == ' ') p++
        }

        fun expr(): Double {
            var v = term()
            while (true) {
                ws()
                if (p < s.length && s[p] == '+') { p++; v += term() }
                else if (p < s.length && s[p] == '-') { p++; v -= term() }
                else return v
            }
        }

        fun term(): Double {
            var v = pow()
            while (true) {
                ws()
                if (p < s.length && (s[p] == '*' || s[p] == '×')) { p++; v *= pow() }
                else if (p < s.length && (s[p] == '/' || s[p] == '÷')) { p++; v /= pow() }
                else if (p < s.length && s[p] == '%') { p++; v %= pow() }
                else return v
            }
        }

        fun pow(): Double {
            val b = unary()
            ws()
            if (p < s.length && s[p] == '^') { p++; return Math.pow(b, pow()) }
            return b
        }

        fun unary(): Double {
            ws()
            if (p < s.length && s[p] == '-') { p++; return -unary() }
            if (p < s.length && s[p] == '+') { p++; return unary() }
            return atom()
        }

        fun atom(): Double {
            ws()
            if (p < s.length && s[p] == '(') {
                p++
                val v = expr()
                ws()
                p++
                return v
            }
            val st = p
            while (p < s.length && (s[p].isDigit() || s[p] == '.')) p++
            if (st == p) throw Exception("Expression bujhini")
            return s.substring(st, p).toDouble()
        }
    }

    private fun calculate(e: String): String {
        val v = Calc(e).parse()
        return if (v == Math.floor(v) && Math.abs(v) < 1e15) v.toLong().toString() else v.toString()
    }

    // ---------- system ----------
    private fun settingsPage(p: String): String {
        val act = when (p.lowercase()) {
            "wifi" -> Settings.ACTION_WIFI_SETTINGS
            "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
            "mobile", "network", "sim", "data" -> Settings.ACTION_DATA_ROAMING_SETTINGS
            "display" -> Settings.ACTION_DISPLAY_SETTINGS
            "sound" -> Settings.ACTION_SOUND_SETTINGS
            "battery" -> Settings.ACTION_BATTERY_SAVER_SETTINGS
            "apps", "app" -> Settings.ACTION_APPLICATION_SETTINGS
            "airplane" -> Settings.ACTION_AIRPLANE_MODE_SETTINGS
            "dnd" -> "android.settings.ZEN_MODE_SETTINGS"
            "storage" -> Settings.ACTION_INTERNAL_STORAGE_SETTINGS
            "location" -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
            "accessibility" -> Settings.ACTION_ACCESSIBILITY_SETTINGS
            "date" -> Settings.ACTION_DATE_SETTINGS
            "language" -> Settings.ACTION_LOCALE_SETTINGS
            "nfc" -> Settings.ACTION_NFC_SETTINGS
            else -> Settings.ACTION_SETTINGS
        }
        launch(Intent(act))
        return "Settings khulechi: $p"
    }

    private fun toggleSetting(n: String): String {
        val s = acc()
        val labels: Array<String> = when (n.lowercase()) {
            "wifi", "wi-fi" -> arrayOf("Wi-Fi", "Internet", "WiFi", "ওয়াই-ফাই")
            "bluetooth" -> arrayOf("Bluetooth", "ব্লুটুথ")
            "airplane", "flight" -> arrayOf("Airplane mode", "Flight mode", "Airplane", "এয়ারপ্লেন")
            "mobile data", "data" -> arrayOf("Mobile data", "Data", "মোবাইল ডেটা")
            "hotspot" -> arrayOf("Hotspot", "Mobile Hotspot")
            "flashlight", "torch" -> arrayOf("Flashlight", "Torch", "টর্চ")
            "auto-rotate", "rotate" -> arrayOf("Auto-rotate", "Auto rotate", "Portrait")
            "battery saver" -> arrayOf("Battery Saver", "Power saving")
            "location" -> arrayOf("Location", "লোকেশন")
            else -> arrayOf(n)
        }
        s.global(AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS)
        sleep(1300)
        val ok = s.clickAny(*labels)
        sleep(700)
        s.global(AccessibilityService.GLOBAL_ACTION_BACK)
        sleep(300)
        s.global(AccessibilityService.GLOBAL_ACTION_BACK)
        return if (ok) "$n tile toggle kora hoyeche (Wi-Fi/Internet tile dialog khulle user-ke ber korte hobe)" else "$n tile pai ni"
    }

    private fun brightness(level: Int): String {
        if (!Settings.System.canWrite(ctx)) {
            launch(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + ctx.packageName)))
            return "PERMISSION_MISSING: Modify system settings. Page khulechi, allow kore abar bolo."
        }
        Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
        Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS, level.coerceIn(0, 100) * 255 / 100)
        return "Brightness $level%"
    }

    private fun dnd(on: Boolean): String {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        if (!nm.isNotificationPolicyAccessGranted) {
            launch(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
            return "PERMISSION_MISSING: Do Not Disturb access. Page khulechi, allow kore abar bolo."
        }
        nm.setInterruptionFilter(if (on) NotificationManager.INTERRUPTION_FILTER_NONE else NotificationManager.INTERRUPTION_FILTER_ALL)
        return if (on) "Do Not Disturb on" else "Do Not Disturb off"
    }

    private fun power(act: String): String {
        if (!confirm(if (act == "restart") "Phone restart korbo?" else "Phone shutdown korbo?")) return "User cancel korlo"
        val s = acc()
        s.global(AccessibilityService.GLOBAL_ACTION_POWER_DIALOG)
        sleep(1400)
        val ok = if (act == "restart") s.clickAny("Restart", "Reboot", "রিস্টার্ট") else s.clickAny("Power off", "Shut down", "বন্ধ করুন")
        return if (ok) "Power button tap kora hoyeche (confirm lagle user-ke chapte hobe)" else "Power menu khulechi, user nije chapbe"
    }

    private fun battery(): String {
        val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return "Battery info nei"
        val lvl = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val sc = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        val st = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val ch = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
        return "Battery ${lvl * 100 / sc}%, " + if (ch) "charging" else "not charging"
    }

    private fun storage(): String {
        val sf = StatFs(Environment.getDataDirectory().path)
        val gb = 1024.0 * 1024 * 1024
        return "Free %.1f GB of %.1f GB".format(sf.availableBytes / gb, sf.totalBytes / gb)
    }

    // ---------- files ----------
    private fun filesAccess(): String? {
        if (Build.VERSION.SDK_INT >= 30 && !Environment.isExternalStorageManager()) {
            launch(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:" + ctx.packageName)))
            return "PERMISSION_MISSING: All files access. Page khulechi, allow kore abar bolo."
        }
        return null
    }

    private fun resolve(p: String): File =
        if (p.startsWith("/")) File(p) else File(Environment.getExternalStorageDirectory(), p)

    private fun fileSearch(q: String, dir: String): String {
        filesAccess()?.let { return it }
        val root = if (dir.isBlank()) Environment.getExternalStorageDirectory() else resolve(dir)
        val res = root.walkTopDown().maxDepth(7).onEnter { it.name != "Android" }
            .filter { it.isFile && it.name.contains(q, true) }
            .take(30).map { it.absolutePath }.toList()
        return if (res.isEmpty()) "Kichu pai ni" else res.joinToString("\n")
    }

    private fun fileCreate(path: String, content: String): String {
        filesAccess()?.let { return it }
        val f = resolve(path)
        if (f.exists() && !confirm("${f.name} already ache, overwrite korbo?")) return "User cancel korlo"
        f.parentFile?.mkdirs()
        f.writeText(content)
        return "File toiri: " + f.absolutePath
    }

    private fun fileRename(path: String, newName: String): String {
        filesAccess()?.let { return it }
        val f = resolve(path)
        if (!f.exists()) return "File nei"
        if (!confirm("${f.name} → $newName rename korbo?")) return "User cancel korlo"
        val t = File(f.parentFile, newName)
        return if (f.renameTo(t)) "Renamed" else "Rename hoy ni"
    }

    private fun fileDelete(path: String): String {
        filesAccess()?.let { return it }
        val f = resolve(path)
        if (!f.exists()) return "File nei"
        if (!confirm("${f.name} delete korbo? Eta ar ferot pawa jabe na.")) return "User cancel korlo"
        val ok = if (f.isDirectory) f.deleteRecursively() else f.delete()
        return if (ok) "Deleted" else "Delete hoy ni"
    }

    private fun mediaUri(f: File): Uri? {
        val base = MediaStore.Files.getContentUri("external")
        val c = ctx.contentResolver.query(
            base, arrayOf(MediaStore.Files.FileColumns._ID),
            MediaStore.Files.FileColumns.DATA + "=?", arrayOf(f.absolutePath), null
        ) ?: return null
        c.use {
            if (it.moveToFirst()) return ContentUris.withAppendedId(base, it.getLong(0))
        }
        return null
    }

    private fun fileOpen(path: String): String {
        filesAccess()?.let { return it }
        val f = resolve(path)
        if (!f.exists()) return "File nei"
        val ext = f.extension.lowercase()
        if (ext in setOf("txt", "md", "json", "csv", "log", "xml", "html", "kt", "java", "py", "js")) {
            return f.readText().take(4000)
        }
        val uri = mediaUri(f) ?: return "File open kora gelo na (MediaStore-e nei)"
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "*/*"
        launch(Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
        return "File khulechi"
    }

    private fun clipboard(act: String, text: String): String {
        val cm = ctx.getSystemService(ClipboardManager::class.java)
        return when (act) {
            "copy" -> {
                cm.setPrimaryClip(ClipData.newPlainText("kks", text))
                "Copied"
            }
            "paste" -> if (acc().paste()) "Pasted" else "Paste kora gelo na"
            else -> cm.primaryClip?.getItemAt(0)?.text?.toString() ?: "Clipboard faka ba read kora gelo na"
        }
    }

    // ---------- screen ----------
    private fun analyzeScreen(q: String): Any {
        val b64 = acc().screenshotB64() ?: return "Screenshot neya gelo na (Android 11+ lage)"
        val arr = JSONArray()
        arr.put(
            JSONObject().put("type", "image").put(
                "source",
                JSONObject().put("type", "base64").put("media_type", "image/jpeg").put("data", b64)
            )
        )
        arr.put(JSONObject().put("type", "text").put("text", "Current screen screenshot. Question: $q"))
        return arr
    }

    private fun screenTap(text: String, x: Int, y: Int): String {
        val s = acc()
        if (text.isNotEmpty()) {
            val ok = s.clickText(text)
            sleep(500)
            return if (ok) "Tapped '$text'" else "'$text' screen-e pai ni"
        }
        if (x >= 0 && y >= 0) {
            s.tap(x.toFloat(), y.toFloat())
            sleep(500)
            return "Tapped $x,$y"
        }
        return "text ba x,y dao"
    }

    private fun navAction(act: String): String {
        val g = when (act) {
            "back" -> AccessibilityService.GLOBAL_ACTION_BACK
            "home" -> AccessibilityService.GLOBAL_ACTION_HOME
            "recents" -> AccessibilityService.GLOBAL_ACTION_RECENTS
            "notifications" -> AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS
            "quick_settings" -> AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS
            else -> return "Unknown action"
        }
        val ok = acc().global(g)
        sleep(400)
        return if (ok) "Done: $act" else "Hoy ni"
    }
}
